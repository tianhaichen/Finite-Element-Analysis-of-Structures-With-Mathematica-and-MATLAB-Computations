% Stiffness matrix for a four node element based on the
% mixed formulation
e=1; nu=0.3;
c = e/(1 - nu^2) * [1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
d=inv(c);
% Use 2x2 integration. Gauss point locations and weights
pt=1/sqrt(3);
gpLocs = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
gpWts = [1,1,1,1];
ka=zeros(5,8); kb=zeros(5,5);
for i=1:length(gpWts)
    s = gpLocs(i, 1); t = gpLocs(i, 2); w = gpWts(i);
    p = [1, 0, 0, 0, 0; 0, 1, 0, 0, 0; 0, 0, 1, s, t]';
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    bt = [dns(1), 0, dns(2), 0, dns(3), 0, dns(4), 0;
        0, dnt(1), 0, dnt(2), 0, dnt(3), 0, dnt(4);
        dnt(1), dns(1), dnt(2), dns(2), dnt(3), dns(3), dnt(4), dns(4)];
    ka = ka + w* p*bt;
    kb = kb + w* p*d*p';
end
kbi=inv(kb);
k = ka' * kbi * ka
sort(eig(k))