function [k, r] = UP41Element(type, e, nu, h, coord)
% [k, r] = UP41Element(type, e, nu, h, coord)
% Generates stiffness matrix for 4/1 mixed element
% type = 1: plane stress, 2: plane strain
% e = Modulus of elasticity
% nu = Poisson's ratio
% h = thickness
% coord = coordinates at the element nodes

gg = e/(2*(1 + nu)); kappa = e/(3*(1 - 2*nu));
cd = [2*gg, 0, 0, 0; 0, 2*gg, 0, 0;
    0, 0, 2*gg, 0; 0, 0, 0, gg];
m = [1, 1, 1, 0]';

% Use 2x2 integration. Gauss point locations and weights
pt=1/sqrt(3);
gpLocs = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
gpWts = [1,1,1,1];
ka=zeros(1,8); r=zeros(8,1);
kb = zeros(1,1);
kc = zeros(8,8);
if type==1
    fact=nu/(nu-1);
else
    fact=0;
end
for i=1:length(gpWts)
    s = gpLocs(i, 1); t = gpLocs(i, 2); w = gpWts(i);
    pp=[1];
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1); y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    dnx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    dny = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [dnx(1), 0, dnx(2), 0, dnx(3), 0, dnx(4), 0;
        0, dny(1), 0, dny(2), 0, dny(3), 0, dny(4);
        fact*dnx(1), fact*dny(1), fact*dnx(2), fact*dny(2)...
        fact*dnx(3), fact*dny(3), fact*dnx(4), fact*dny(4);
        dny(1), dnx(1), dny(2), dnx(2), dny(3), dnx(3), dny(4), dnx(4)]';
    bvt = m'*b';
    bdt = (eye(4) - 1/3 * m * m')* b';
    bd = bdt';
     ka = ka + h*detJ*w * pp*bvt;
    kb = kb + h*detJ*w/kappa * pp*pp';
    kc = kc + h*detJ*w* bd*cd*bdt;
end
k = kc + ka' * inv(kb) * ka;
end