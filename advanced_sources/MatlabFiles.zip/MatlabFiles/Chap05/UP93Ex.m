% One element example 5.5
nodes = [0, 0; 5, 0; 10, 0; 10, 5; 10, 10; 
    5, 10; 0, 10; 0, 5; 5, 5];
conn = [1, 2, 3, 4, 5, 6, 7, 8, 9];
e = 10^6; nu = .49; type=1; h =0.1; p=-1000;
nel=size(conn,1);
dof=2*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:9
        lm=[lm, [2*conn(i,j)-1,2*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = UP93Element(type, e, nu, h, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
R(lmm(1,:)) = R(lmm(1,:)) + ...
    UP93ElementLoad(3, -p, 0, h, nodes(conn(1,:),:));
% Nodal solution and reactions
debc = [1, 2, 13, 14, 15, 16]; ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals);
d
for i=1:nel
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=UP93ElementResults(type, e, nu, h, ...
        nodes(conn(i,:),:), d(lmm(i,:)), [0,0; -1,1])
end