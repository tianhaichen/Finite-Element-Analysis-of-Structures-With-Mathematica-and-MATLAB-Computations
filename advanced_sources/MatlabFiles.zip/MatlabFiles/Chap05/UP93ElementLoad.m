function rq = UP93ElementLoad(side, qn, qt, h, coord)
% rq = UP93ElementLoad(side, qn, qt, h, coord)
% Generates equivalent load vector
% side = side over which the load is specified
% qn, qt = load components in the normal and the tangential direction
% h = element thickness
% coord = coordinates at the element ends

% Use 2 point integration. Gauss point locations and weights
pt=-1/sqrt(3);
gpLocs = [-pt, pt];
gpWts = [1,1];
rq=zeros(18,1);
for i=1:length(gpWts)
    a = gpLocs(i); w = gpWts(i);
    switch (side)
        case 1
            n = [((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0, 0, 0, 0, 0, 0];
            nmap = [((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0, 0, 0, 0, 0];
            dnamap = [-1/2 + a, -2*a, 1/2 + a, 0, 0, 0, 0, 0];
        case 2
            n = [0, 0, ((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0, 0, 0, 0];
            nmap = [0, 0, ((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0, 0, 0];
            dnamap = [0, 0, -1/2 + a, -2*a, 1/2 + a, 0, 0, 0];
        case 3
            n = [0, 0, 0, 0, ((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0, 0];
            nmap = [0, 0, 0, 0, ((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0];
            dnamap = [0, 0, 0, 0, -1/2 + a, -2*a, 1/2 + a, 0];
        case 4
            n = [(a*(1 + a))/2, 0, 0, 0, 0, 0, ((-1 + a)*a)/2, 1 - a^2, 0];
            nmap = [a*(1 + a)/2, 0, 0, 0, 0, 0, ((-1 + a)*a)/2, 1 - a^2];
            dnamap = [1/2 + a, 0, 0, 0, 0, 0, -1/2 + a, -2*a];
    end
    x = nmap*coord(1:8,1);
    dxa = dnamap*coord(1:8,1); dya = dnamap*coord(1:8,2);
    Jc=sqrt(dxa^2 + dya^2);
    nx = dya/Jc; ny = -dxa/Jc;
    qx = nx*qn - ny*qt;
    qy = ny*qn + nx*qt;
    n = [n(1),0,n(2),0,n(3),0,n(4),0, ...
        n(5),0,n(6),0,n(7),0,n(8),0, n(9),0;
        0,n(1),0,n(2),0,n(3),0,n(4), ...
        0,n(5),0,n(6),0,n(7),0,n(8),0,n(9)];
    rq = rq + h*Jc*w*n'*[qx; qy];
end
