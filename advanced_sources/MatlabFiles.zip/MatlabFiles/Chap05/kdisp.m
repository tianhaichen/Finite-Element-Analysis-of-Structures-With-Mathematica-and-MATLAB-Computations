% Stiffness matrix for a four node element based on the 
% standard displacement formulation
e=1; nu=0.3;
c = e/(1 - nu^2) * [1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
% Use 2x2 integration. Gauss point locations and weights
pt=1/sqrt(3);
gpLocs = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
gpWts = [1,1,1,1];
k=zeros(8); r=zeros(8,1);
for i=1:length(gpWts)
    s = gpLocs(i, 1); t = gpLocs(i, 2); w = gpWts(i);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
            (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    b = [dns(1), 0, dns(2), 0, dns(3), 0, dns(4), 0; 
        0, dnt(1), 0, dnt(2), 0, dnt(3), 0, dnt(4);
        dnt(1), dns(1), dnt(2), dns(2), dnt(3), dns(3), dnt(4), dns(4)];
    k = k + w* b'*c*b;
end
k
sort(eig(k))