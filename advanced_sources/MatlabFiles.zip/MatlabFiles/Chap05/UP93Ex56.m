% 16 element example 5.6
nodes = [0, 0; 0, 5/4; 0, 5/2; 0, 15/4; 0, 5; 5/2, 0;
    5/2, 5/4; 5/2, 5/2; 5/2, 15/4; 5/2, 5; 5, 0; 5, 5/4;
    5, 5/2; 5, 15/4; 5, 5; 15/2, 0; 15/2, 5/4; 15/2, 5/2;
    15/2, 15/4; 15/2, 5; 10, 0; 10, 5/4; 10, 5/2; 10, 15/4; 10, 5];
conn = [1, 6, 11, 12, 13, 8, 3, 2, 7;
    3, 8, 13, 14, 15, 10, 5, 4, 9;
    11, 16, 21, 22, 23, 18, 13, 12, 17;
    13, 18, 23, 24, 25, 20, 15, 14, 19];
e = 10^6; nu = .499; type=2; h =1; p=-10^5;
nel=size(conn,1);
dof=2*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:9
        lm=[lm, [2*conn(i,j)-1,2*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = UP93Element(type, e, nu, h, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
R(lmm(2,:)) = R(lmm(2,:)) + ...
    UP93ElementLoad(3, -p, 0, h, nodes(conn(2,:),:));
% Nodal solution and reactions
debc = [3, 5, 7, 9, 41, 42, 43, 44, 45, 46, ...
    47, 48, 49, 50, 1, 2, 11, 12, 21, 22, 31, 32];
ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals);
d
for i=1:nel
    fprintf(1,'Results for element %2d \n',i)
    EffectiveStress=UP93ElementResults(type, e, nu, h, ...
        nodes(conn(i,:),:), d(lmm(i,:)), [0,0; -1,1])
end