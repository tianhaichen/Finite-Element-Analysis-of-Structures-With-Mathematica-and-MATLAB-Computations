% Evaluate line integral along side 3 of the element
% Use 3 point integration. Gauss point locations and weights
gpLocs = [-sqrt(3/5), 0, sqrt(3/5)];
gpWts = [5/9, 8/9, 5/9];
ka=zeros(8);
for i=1:length(gpWts)
    a = gpLocs(i); w = gpWts(i);
        n = [0, 0, 0, 0, (1 - a)/2 + (-1 + a^2)/2, ...
                1 - a^2,(1 + a)/2 + (-1 + a^2)/2, 0];
        dna = [0, 0, 0, 0, -1/2 + a, -2*a, 1/2 + a, 0];
    dxa = dna*coord(:,1); dya = dna*coord(:,2);
    Jc=sqrt(dxa^2 + dya^2);
    ka = ka + Jc*w*n'*n;
end
ka
