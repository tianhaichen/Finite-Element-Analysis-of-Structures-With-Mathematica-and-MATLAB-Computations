% Deformation gradient example 9.3
initialCoord = [0,0; 1,0; 1,1; 0,1];
currentCoord = [1, 1; 1 + sqrt(3)/2, 3/2; 
    1/2 + sqrt(3)/2, 3/2 + sqrt(3)/2; 1/2, 1 + sqrt(3)/2];
d = reshape((currentCoord-initialCoord)', 8,1);
[F, J, JC] = DefGrad2DQuad(initialCoord, d, 0, 0) 