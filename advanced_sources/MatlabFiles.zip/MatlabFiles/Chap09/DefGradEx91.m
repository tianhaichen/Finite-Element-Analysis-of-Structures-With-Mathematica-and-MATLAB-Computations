% Deformation gradient example 9.1
initialCoord = [0,0,0; 1,0,0; 1,1,0; 0,1,0; 0,0,1;
    1,0,1; 1,1,1; 0,1,1];
currentCoord = [2, 1, 2; 2 + (3*sqrt(3))/5, 2/5, 2;
    13/5 + (3*sqrt(3))/5, 2/5 + (3*sqrt(3))/5, 2;
    13/5, 1 + (3*sqrt(3))/5, 2; 2, 1, 16/5;
    2 + (3*sqrt(3))/5, 2/5, 16/5; 
    13/5 + (3*sqrt(3))/5, 2/5 + (3*sqrt(3))/5, 16/5;
    13/5, 1 + (3*sqrt(3))/5, 16/5];
d = reshape((currentCoord-initialCoord)', 24,1);
[F, J, JC] = DefGrad3DBrick(initialCoord, d, 0, 0, 0) 