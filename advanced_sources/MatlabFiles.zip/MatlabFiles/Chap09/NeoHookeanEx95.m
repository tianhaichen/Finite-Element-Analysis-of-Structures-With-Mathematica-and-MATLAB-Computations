% Neo-Hookean Model example 9.5
coord = [0,0; 1,0; 1,1; 0,1];
d=[0.25, 0.5, 0.3325317547305482, 1.125,... 
 -0.017468245269451788, 0.7312177826491071, -0.1,... 
 0.10621778264910686];
e=30000; nu=0.3; h0=0.2;
lambda = e * nu/((1+nu)*(1-2*nu));
mu = e/(2*(1+nu));
gamma = 2*mu/(lambda + 2*mu);
[pk, sig, eps, h, JC] = NeoHookeanStressStrain(lambda, mu, gamma, h0, ...
    coord, d, 0,0)