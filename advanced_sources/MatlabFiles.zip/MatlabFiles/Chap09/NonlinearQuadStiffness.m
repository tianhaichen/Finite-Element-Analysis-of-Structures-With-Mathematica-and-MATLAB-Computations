function [kc, ks, re, ri] = NonlinearQuadStiffness(type, e, nu, h, d,...
    coord)
% [kc, ks, re, ri] = NonlinearQuadStiffness(type, e, nu, h, d, coord)
% Generates stiffness matrix for 4/1 mixed element
% type = 1: plane stress, 2: plane strain
% e = Modulus of elasticity
% nu = Poisson's ratio
% h = thickness
% d = nodal displacement vector
% coord = coordinates at the element nodes

% Use 2x2 integration. Gauss point locations and weights
pt=1/sqrt(3);
gpLocs = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
gpWts = [1,1,1,1];
ks = zeros(8); re=zeros(8,1); ri=re;
kc = zeros(8);
for i=1:length(gpWts)
    s = gpLocs(i, 1); t = gpLocs(i, 2); w = gpWts(i);
    lambda = e * nu/((1+nu)*(1-2*nu));
    mu = e/(2*(1+nu));
    if type == 1
        gamma = 2*mu/(lambda + 2*mu);
    else
        gamma = 1;
    end
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    [F, J, JC] = DefGrad2DQuad(coord, d, s, t);
    [c, pkt] = NeoHookeanCmat(lambda, mu, gamma, det(F), inv(F'*F));
    sbar = zeros(4); sbar(1:2, 1:2)=pkt; sbar(3:4, 3:4)=pkt;
    fbar = [F(1, 1), 0, F(2, 1), 0;
        0, F(1, 2), 0, F(2, 2);
        F(1, 2), F(1, 1), F(2, 2), F(2, 1)];
    detJ = det(J);
    dnx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    dny = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    bt = [dnx(1), 0, dnx(2), 0, dnx(3), 0, dnx(4), 0;
        dny(1), 0, dny(2), 0, dny(3), 0, dny(4), 0;
        0, dnx(1), 0, dnx(2), 0, dnx(3), 0, dnx(4);
        0, dny(1), 0, dny(2), 0, dny(3), 0, dny(4)];
    b=bt'; GT = fbar*bt; G = GT';
    kc = kc + h*detJ*w * G*c*GT;
    ks = ks + h*detJ*w*b*sbar*bt;
    ri =ri + h*detJ*w*G*[pkt(1, 1); pkt(2, 2); pkt(1, 2)];
end
end % NonlinearQuadStiffness