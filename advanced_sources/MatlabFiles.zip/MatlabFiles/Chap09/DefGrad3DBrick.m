function [F, J, JC] = DefGrad3DBrick(initialCoord, d, r, s, t)
% [F] = DefGrad3DBrick(initialCoord, currCoord, r, s, t)
% Compute deformation gradient for a 3D brick element 
%   at given point r, s, t.
% initialCoord = initial coordinates 
% d = nodal displacements

currCoord = initialCoord + reshape(d,3,8)';
dnr = [-((-1 + s)*(-1 + t))/8, ((-1 + s)*(-1 + t))/8,... 
 -((1 + s)*(-1 + t))/8, ((1 + s)*(-1 + t))/8,... 
 ((-1 + s)*(1 + t))/8, -((-1 + s)*(1 + t))/8, ...
 ((1 + s)*(1 + t))/8, -((1 + s)*(1 + t))/8];
dns = [-((-1 + r)*(-1 + t))/8, ((1 + r)*(-1 + t))/8, ...
 -((1 + r)*(-1 + t))/8, ((-1 + r)*(-1 + t))/8, ...
 ((-1 + r)*(1 + t))/8, -((1 + r)*(1 + t))/8, ...
 ((1 + r)*(1 + t))/8, -((-1 + r)*(1 + t))/8];
dnt = [-((-1 + r)*(-1 + s))/8, ((1 + r)*(-1 + s))/8,... 
 -((1 + r)*(1 + s))/8, ((-1 + r)*(1 + s))/8, ...
 ((-1 + r)*(-1 + s))/8, -((1 + r)*(-1 + s))/8, ...
 ((1 + r)*(1 + s))/8, -((-1 + r)*(1 + s))/8];
dx0r = dnr * initialCoord(:,1); dxr = dnr * currCoord(:,1); 
dy0r = dnr * initialCoord(:,2); dyr = dnr * currCoord(:,2); 
dz0r = dnr * initialCoord(:,3); dzr = dnr * currCoord(:,3); 

dx0s = dns * initialCoord(:,1); dxs = dns * currCoord(:,1); 
dy0s = dns * initialCoord(:,2); dys = dns * currCoord(:,2); 
dz0s = dns * initialCoord(:,3); dzs = dns * currCoord(:,3); 

dx0t = dnt * initialCoord(:,1); dxt = dnt * currCoord(:,1); 
dy0t = dnt * initialCoord(:,2); dyt = dnt * currCoord(:,2); 
dz0t = dnt * initialCoord(:,3); dzt = dnt * currCoord(:,3); 

J = [dx0r, dx0s, dx0t; dy0r, dy0s, dy0t; dz0r, dz0s, dz0t];
JC = [dxr, dxs, dxt; dyr, dys, dyt; dzr, dzs, dzt];
F = (inv(J')*JC')';
end % DefGrad3DBrick

