function [pk, sig, eps, h, JC] = NeoHookeanStressStrain(lambda,...
mu, gamma, h0, coord, d, s, t)
% [pk, sig, eps, h] = NeoHookeanStressStrain(e, nu, coord, d)
% Compute stresses, strains, and new thickness
% pk = second PK stress tensor, sig = Cauchy stress vector
% eps = Green-Lagrange strain vector
% h = new thickness
% lambda, mu, gamma = material parameters
% coord = Initial coordinates
% d = nodal displacements
% h0 = Initial thickness
% s, t = master element coordinates for computations

[F, J, JC] = DefGrad2DQuad(coord, d, s, t);
detF2 = det(F); detF2g = detF2^gamma; lnDetF = log(detF2g);
c=F'*F; ci = inv(c); b = F*F';
pk = lambda*lnDetF * ci + mu*(eye(2)-ci);
sig = (lambda/detF2g)* lnDetF * eye(2) + (mu/detF2g)*(b - eye(2));
eps = 1/2 * (c - eye(2));
h = h0* detF2^(gamma-1);
end % NeoHookeanStressStrain

