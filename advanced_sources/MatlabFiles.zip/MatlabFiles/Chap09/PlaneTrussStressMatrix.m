function k = PlaneTrussStressMatrix(p, coord)
% PlaneTrussStressMatrix(p, coord)
% Generates initial stress matrix for a plane truss element
% p = axial force
% coord = coordinates at the element ends

x1=coord(1,1); y1=coord(1,2);
x2=coord(2,1); y2=coord(2,2);
L=sqrt((x2-x1)^2+(y2-y1)^2);
k = p/L*[1, 0, -1, 0; 0, 1, 0, -1; -1, 0, 1, 0; 0, -1, 0, 1];