function [ri, se] = NonlinearQuadElementSoln(type, e, nu, h0, coord, d)
% [ri, se] = NonlinearQuadElementSoln(type, e, nu, h0, coord, d)
% Computes element solution for a plane stress/strain quad element
% e = modulus of elasticity
% nu = Poisson's ratio
% coord = nodal coordinates
% h0 = initial thickness
% d = nodal displacements
se=[];
pt=1/sqrt(3);
gpLocs = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
gpWts = [1,1,1,1];
ri=zeros(8,1);
for i=1:length(gpWts)
    s = gpLocs(i, 1); t = gpLocs(i, 2); w = gpWts(i);
    lambda = e * nu/((1+nu)*(1-2*nu));
    mu = e/(2*(1+nu));
    if type == 1
        gamma = 2*mu/(lambda + 2*mu);
    else
        gamma = 1;
    end
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    [pk, sig, eps, h, JC] = NeoHookeanStressStrain(lambda, mu, gamma, ...
        h0, coord, d, s, t);
    detJ = det(JC);
    dnx = (JC(2, 2)*dns - JC(2, 1)*dnt)/detJ;
    dny = (-JC(1, 2)*dns + JC(1, 1)*dnt)/detJ;
    b = [dnx(1), 0, dnx(2), 0, dnx(3), 0, dnx(4), 0;
        0, dny(1), 0, dny(2), 0, dny(3), 0, dny(4);
        dny(1), dnx(1), dny(2), dnx(2), dny(3), dnx(3), dny(4), dnx(4)]';
    sx = sig(1,1); sy= sig(2,2); sxy=sig(1,2);
    ri =ri + h*detJ*w*b*[sx; sy; sxy];
    sz=0;
    if type==2
        detF = det(F);
        sz=lambda*log(detF^gamma)/detF;
    end
    se = [se, sqrt((sx - sy)^2 + (sy - sz)^2 +(sz - sx)^2 + ...
        6*sxy^2)/sqrt(2)];
end
end % NonlinearQuadElementSoln