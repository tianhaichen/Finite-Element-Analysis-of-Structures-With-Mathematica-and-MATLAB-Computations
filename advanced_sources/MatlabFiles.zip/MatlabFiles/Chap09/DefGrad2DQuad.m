function [F, J, JC] = DefGrad2DQuad(initialCoord, d, s, t)
% [F] = DefGrad2DQuad(initialCoord, currCoord, s, t)
% Compute deformation gradient for a 2D quadrilateral element 
%   at given point s, t.
% initialCoord = initial coordinates 
% d = nodal displacements
currCoord = initialCoord + reshape(d,2,4)';

dns = [(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
dnt = [(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];

dx0s = dns * initialCoord(:,1); dxs = dns * currCoord(:,1); 
dy0s = dns * initialCoord(:,2); dys = dns * currCoord(:,2); 
dx0t = dnt * initialCoord(:,1); dxt = dnt * currCoord(:,1); 
dy0t = dnt * initialCoord(:,2); dyt = dnt * currCoord(:,2); 

J = [dx0s, dx0t; dy0s, dy0t];
JC = [dxs, dxt; dys, dyt];
F = (inv(J')*JC')';
end % DefGrad2DQuad

