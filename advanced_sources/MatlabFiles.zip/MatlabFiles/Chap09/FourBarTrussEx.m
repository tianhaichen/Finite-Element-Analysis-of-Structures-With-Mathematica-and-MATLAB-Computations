% Four bar truss example p. 539
e = 200*10^3; a = 0.0002*1000^2 * [2,2,1,1]; P = 40000; alpha=pi/3;
nodes = 1000*[0, -1; 4, 0; 4, 3; 2, 2];
conn = [1, 2; 1, 4; 2, 4; 2, 3];
lmm = [1, 2, 3, 4; 1, 2, 7, 8; 3, 4, 7, 8; 3, 4, 5, 6];
nel = 4; dof = 8;
K=zeros(dof);Ks=zeros(dof); R=zeros(dof,1);
R(3) = P*sin(alpha); R(4) = P*cos(alpha); R(7) = -P;
for i=1:nel
    lm=lmm(i,:);
    con=conn(i,:);
    k=PlaneTrussElement(e, a(i), nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
end
% Nodal solution and reactions
debc=[1,2,5,6]; ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals)
axialForces=[];
for i=1:nel
    [eps, sigma, force] = PlaneTrussResults(e, a(i), ...
        nodes(conn(i,:),:), d(lmm(i,:)));
    axialForces=[axialForces, force];
end
axialForces
for i=1:nel
    lm=lmm(i,:);
    con=conn(i,:);
    k=PlaneTrussStressMatrix(axialForces(i), nodes(con,:));
    Ks(lm, lm) = Ks(lm, lm) + k;
end
df=[3,4,7,8];
Kf=K(df,df)
Ksf=Ks(df,df)
ev=sort(eig(Kf, -Ksf))
for i=1:length(ev)
    if ev(i)<0
        ev(i)=NaN;
    end
end
fact=min(ev);
fprintf(1,'Buckling load factor = %10.4g \n', fact)
fprintf(1,'Buckling load = %10.4g \n', fact*P)
