% Example 9.6
e=1000; nu=0.25; h = 0.1;
nodes = [0, 0; 4, 1; 4, 2; 0, 2];
dof=2*length(nodes);
conn=reshape([1, 2, 3, 4],1,4);
lmm = reshape([1, 2, 3, 4, 5, 6, 7, 8],1,8);
nel=1;
debc = [1, 2, 7,8]; ebcVals=zeros(length(debc),1);
df = [3, 4, 5,6];
loadFactors = [1];
d = zeros(dof,1);
for step=1:length(loadFactors)
    lambda = loadFactors(step);
    fprintf(1,'**************************** \n')
    fprintf(1,'Current load parameter: %4.2g \n', lambda)
    fprintf(1,'**************************** \n')
    conv = 1; iter = 1; tol = 0.01;
    while conv > tol & iter < 10
        fprintf(1,'Iteration: %3d \n', iter)
        KT = zeros(dof); R = zeros(dof,1); Ri=zeros(dof,1);
        R(3) = lambda*50;
        R(5) = lambda*25;
        for i=1:nel
            lm = lmm(i,:);
            con=conn(i,:);
            [kc, ks, r, ri] = NonlinearQuadStiffness (1, e, nu, h, ...
                d(lm), nodes(con,:));
            KT(lm, lm) = KT(lm, lm) + kc + ks;
            R(lm) = R(lm) + r;
            Ri(lm) = Ri(lm) + ri;
        end
        KT
        R
        Ri
        % Nodal solution and reactions
        [dd, reactions] = NodalSoln(KT, -Ri+R, debc, ebcVals);
        d = d + dd;
        Ri=zeros(dof,1);
        fprintf(1,'Solution of incremental equations: \n')
        disp(dd)
        fprintf(1,'Total nodal values: \n')
        disp(d)
        for i=1:nel
            lm = lmm(i,:);
            con=conn(i,:);
            [ri, se] = NonlinearQuadElementSoln(1, e, nu, h,...
            nodes(con,:), d(lm));
            Ri(lm) = Ri(lm) + ri;
        end
        Ri
        Rf = R(df); Ff = -Ri(df) + Rf;
        conv = sqrt(Ff'*Ff)/(1 + sqrt(Rf'*Rf));
        fprintf(1,'Convergence parameter: %11.4g \n', conv)
        iter = iter + 1;
    end
end