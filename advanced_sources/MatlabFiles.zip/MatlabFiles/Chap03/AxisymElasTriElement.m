function [ke, re] = AxisymElasTriElement(e, nu, alpha, deltaT, ...
    omega, m, bx, by, coord)
% [ke, re] = AxisymElasTriElement(e, nu, alpha, deltaT, 
%   omega, m, bx, by, coord)
% Generates for a triangular element for plane stress or plane strain problem
% e = Modulus of elasticity
% nu = Poisson's ratio
% alpha = coefficient of thermal expansion
% deltaT = temperature change
% omega, m = Angular velocity and mass
% bx, by = components of the body force
% coord = coordinates at the element ends

x1=coord(1,1); y1=coord(1,2);
x2=coord(2,1); y2=coord(2,2);
x3=coord(3,1); y3=coord(3,2);
b1 = y2 - y3; b2 = y3 - y1; b3 = y1 - y2;
c1 = x3 - x2; c2 = x1 - x3; c3 = x2 - x1;
f1 = x2*y3 - x3*y2; f2 = x3*y1 - x1*y3; f3 = x1*y2 - x2*y1;
A = (f1 + f2 + f3)/2;
rbar = (x1 + x2 + x3)/3; zbar = (y1 + y2 + y3)/3;
e0 = alpha*deltaT *[1, 1, 1, 0]';
c = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0;
    nu, 1 - nu, nu, 0;
    nu, nu, 1 - nu, 0;
    0, 0, 0, (1 - 2*nu)/2];
b = (1/(2*A))*[b1, 0, b2, 0, b3, 0;
    0, c1, 0, c2, 0, c3;
    2*A/(3*rbar), 0, 2*A/(3*rbar), 0, 2*A/(3*rbar), 0;
    c1, b1, c2, b2, c3, b3]';
ke = 2*pi*rbar*A*b*c*b';
br = bx + m*rbar*omega^2; bz = by;
rb = 2*pi*rbar*A/3 * [br, bz, br, bz, br, bz]';
re0 = 2*pi*rbar*A*b*c*e0;
re = rb+re0;
end
