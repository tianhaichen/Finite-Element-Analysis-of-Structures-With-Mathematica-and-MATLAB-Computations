function se = AxiQuad4Results(e, nu, alpha, deltaT, coord, dn)
% se = AxiQuad4Results(e, nu, alpha, deltaT, coord, dn)
% Computes element solution for a plane stress/strain quad element
% e = modulus of elasticity
% nu = Poisson's ratio
% alpha = coefficient of thermal expansion
% deltaT = temperature change
% coord = nodal coordinates
% dn = nodal displacements
% Following are the output variables are at element center
% {strains, stresses, principal stresses, effective stress}
e0 = alpha*deltaT *[1, 1, 1, 0]';
c = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0;
    nu, 1 - nu, nu, 0;
    nu, nu, 1 - nu, 0;
    0, 0, 0, (1 - 2*nu)/2];
s = 0; t = 0;
pt=1/sqrt(3);
solPts = [-pt,-pt; -pt,pt; pt,-pt; pt,pt];
se=[];
for i=1:length(solPts)
    s = solPts(i, 1); t = solPts(i, 2);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1);
    y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    dnx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    dny = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [dnx(1), 0, dnx(2), 0, dnx(3), 0, dnx(4), 0;
        0, dny(1), 0, dny(2), 0, dny(3), 0, dny(4);
        n(1)/x, 0, n(2)/x, 0, n(3)/x, 0, n(4)/x, 0;
        dny(1), dnx(1), dny(2), dnx(2), dny(3), dnx(3), dny(4), dnx(4)];
    eps = b*dn;
    sig = c*(eps-e0);
    sx = sig(1); sy= sig(2); sxy=sig(4);
    ps = eig([sx,sxy; sxy,sy]);
    se = [se, sqrt((ps(1) - ps(2))^2 + (ps(2) - sig(3))^2 + ...
        (sig(3) - ps(1))^2)/sqrt(2)];
end