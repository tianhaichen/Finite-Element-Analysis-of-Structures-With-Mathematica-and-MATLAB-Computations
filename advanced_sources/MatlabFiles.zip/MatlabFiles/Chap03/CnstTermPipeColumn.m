function [nsol, esol] = CnstTermPipeColumn(a0, e, nu, nodes, conn)
debc = [1,2,3,4]; ebcVals=zeros(length(debc),1);
alpha = 0; deltaT = 0 ; bx=0; by=0;
nel=size(conn,1); dof=2*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:4
        lm=[lm, [2*conn(i,j)-1,2*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = AxiQuad4Element(e, nu, alpha, deltaT, ...
        bx, by, nodes(con,:));
    r = r + AxiQuad4Load(2, a0, 0, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, ebcVals);
nsol = [];
for i=1:2:dof
    nsol = [nsol,[d(i), 0, d(i+1)]];
end
esol=[];
for i=1:nel
    EffectiveStress=AxiQuad4Results(e, nu, alpha, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)));
    esol = [esol, EffectiveStress]; 
end
