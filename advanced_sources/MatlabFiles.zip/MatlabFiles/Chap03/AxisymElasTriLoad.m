function rq = AxisymElasTriLoad(side, qn, qt, coord)
% AxisymElasTriLoad(side, qn, qt, coord)
% Generates equivalent load vector for a triangular element
% side = side over which the load is specified
% qn, qt = load components in the normal and the tangential direction
% coord = coordinates at the element ends

x1=coord(1,1); y1=coord(1,2);
x2=coord(2,1); y2=coord(2,2);
x3=coord(3,1); y3=coord(3,2);
switch (side)
case 1
    L=sqrt((x2-x1)^2+(y2-y1)^2);
    nx=(y2-y1)/L; ny=-(x2-x1)/L;
    qx = nx*qn - ny*qt;
    qy = ny*qn + nx*qt;
    rq = pi*L/3 * [(2*x1 + x2)*qx, (2*x1 + x2)*qy,...
        (x1 + 2*x2)*qx, (x1 + 2*x2)*qy, 0, 0]';
case 2
    L=sqrt((x2-x3)^2+(y2-y3)^2);
    nx=(y3-y2)/L; ny=-(x3-x2)/L;
    qx = nx*qn - ny*qt;
    qy = ny*qn + nx*qt;
    rq = pi*L/3 * [0, 0, (2*x2 + x3)*qx, (2*x2 + x3)*qy,...
        (x2 + 2*x3)*qx, (x2 + 2*x3)*qy]';
case 3
    L=sqrt((x3-x1)^2+(y3-y1)^2);
    nx=(y1-y3)/L; ny=-(x1-x3)/L;
    qx = nx*qn - ny*qt;
    qy = ny*qn + nx*qt;
    rq = pi*L/3 * [(2*x3 + x1)*qx, (2*x3 + x1)*qy,...
        0, 0, (x3 + 2*x1)*qx, (x3 + 2*x1)*qy]';
end