% Pipe column example
% Load fourier coefficients
p=-5;
a0 = p/4; an=[p/pi, 0, -p/(3*pi)]; bn=[p/pi, p/pi, p/(3*pi)];
e = 200000; nu = .25; p = -5;
h = 1000; ri = 50; ro = 100;
nodes = [ri, 0; ro, 0; ri, h/5; ro, h/5;...
    ri, (2*h)/5; ro, (2*h)/5; ri, (3*h)/5; ...
    ro, (3*h)/5; ri, (4*h)/5; ro, (4*h)/5; ri, h; ro, h];
conn = [1, 2, 4, 3; 3, 4, 6, 5; 5, 6, 8, 7; ...
    7, 8, 10, 9; 9, 10, 12, 11];
nnodes = length(nodes); nelems = length(conn);
fprintf(1,'\n\n=============================\n')
fprintf(1,'Results for axisymmetric term\n')
fprintf(1,'=============================\n')
[nsol, esol] = CnstTermPipeColumn(a0, e, nu, nodes, conn);
printResults(nsol, esol, nnodes, nelems)
for j=1:length(an)
    fprintf(1,'\n\n===============================\n')
    fprintf(1,'Results for symmetric term %3.0g \n',j)
    fprintf(1,'===============================\n')
    [ns, es] = SymmetricTermsPipeColumn(j, an(j), e, nu, nodes, conn);
    printResults(ns, es, nnodes, nelems)
    nsol = [nsol; ns];
    esol = [esol; es];
end
for j=1:length(bn)
    fprintf(1,'\n\n====================================\n')
    fprintf(1,'Results for antisymmetric term %3.0g \n',j)
    fprintf(1,'====================================\n')
    [ns, es] = AntisymmetricTermsPipeColumn(j, bn(j), e, nu, nodes, conn);
    printResults(ns, es, nnodes, nelems)
    nsol = [nsol; ns];
    esol = [esol; es];
end
[n,m] = size(nsol);
ns = nsol(1,:);
es = esol(1,:);
for i=2:n
    ns = ns+nsol(i,:);
    es = es+esol(i,:);
end
fprintf(1,'\n\n===============================\n')
fprintf('           Combined results \n')
fprintf(1,'===============================\n')
printResults(ns, es, nnodes, nelems)


