function se = SymmetricQuad4Results(j, theta, e, nu, coord, dn)
% se = SymmetricQuad4Results(e, nu, coord, dn)
% Computes element solution
% e = modulus of elasticity
% nu = Poisson's ratio
% coord = nodal coordinates
% dn = nodal displacements
c = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0, 0, 0;
    nu, 1 - nu, nu, 0, 0, 0;
    nu, nu, 1 - nu, 0, 0, 0;
    0, 0, 0, (1 - 2*nu)/2, 0, 0;
    0, 0, 0, 0, (1 - 2*nu)/2, 0;
    0, 0, 0, 0, 0, (1 - 2*nu)/2];
s = 0; t = 0;
pt=1/sqrt(3);
solPts = [-pt,-pt,theta; -pt,pt,theta; pt,-pt,theta; pt,pt,theta];
se=[];
for i=1:length(solPts)
    s = solPts(i, 1); t = solPts(i, 2);
    cn = cos(theta); sn = sin(theta);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1);
    y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    dnx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    dny = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [cn*dnx(1), 0, 0, cn*dnx(2), 0, 0, cn*dnx(3), 0, 0, ...
        cn*dnx(4), 0, 0;
        0, 0, cn*dny(1), 0, 0, cn*dny(2), 0, 0, cn*dny(3),...
        0, 0, cn*dny(4);
        cn*n(1)/x, cn*j*n(1)/x, 0, cn*n(2)/x, cn*j*n(2)/x, 0, ...
        cn*n(3)/x, cn*j*n(3)/x, 0, cn*n(4)/x, cn*j*n(4)/x, 0;
        cn*dny(1), 0, cn*dnx(1), cn*dny(2), 0, cn*dnx(2), ...
        cn*dny(3), 0, cn*dnx(3), cn*dny(4), 0, cn*dnx(4);
        0, sn*dny(1), -sn*j*n(1)/x, 0, sn*dny(2), -sn*j*n(2)/x,...
        0, sn*dny(3), -sn*j*n(3)/x, 0, sn*dny(4), -sn*j*n(4)/x;
        (-sn*j*n(1)/x), sn*(dnx(1)-(n(1)/x)), 0, ...
        (-sn*j*n(2)/x), sn*(dnx(2)-(n(2)/x)), 0,...
        (-sn*j*n(3)/x), sn*(dnx(3)-(n(3)/x)), 0,...
        (-sn*j*n(4)/x), sn*(dnx(4)-(n(4)/x)), 0];
 eps = b*dn;
    sig = c*(eps);
    ps = eig([sig(1), sig(4), sig(6);
        sig(4), sig(2), sig(5);
        sig(6), sig(5), sig(3)]);
    se = [se, sqrt(((ps(1) - ps(2))^2 + (ps(2) - ps(3))^2 +...
        (ps(3) - ps(1))^2)/2)];
end