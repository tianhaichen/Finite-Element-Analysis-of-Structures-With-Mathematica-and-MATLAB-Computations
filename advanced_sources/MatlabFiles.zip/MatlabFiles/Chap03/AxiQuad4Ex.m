% Steel and aluminum assembly solution using 3 axisymmetric elements for
% half of the assembly (Fig 3.9)
a = 15; b = 40; ri = 10; ro = 20; rr = 35;
nodes = [ri, 0; ro, 0; rr, 0; ri, a; ro, a; rr, a; ri, b; ro, b];
conn = [1, 2, 5, 4; 2, 3, 6, 5; 4, 5, 8, 7];  
e1 = 70000; nu1 = .33; alpha1 = 23*10^(-6);
e2 = 200000; nu2 = .3; alpha2 = 12*10^(-6); deltaT = -75;
bx=0; by=0;
nel=size(conn,1); dof=2*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:4
        lm=[lm, [2*conn(i,j)-1,2*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:2:3
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = AxiQuad4Element(e1, nu1, alpha1, deltaT, ...
        bx, by, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
for i=2:2
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = AxiQuad4Element(e2, nu2, alpha2, deltaT, ...
        bx, by, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
debc = [2,4,6]; ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals)
for i=1:2:3
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=AxiQuad4Results(e1, nu1, alpha1, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)))
end
for i=2:2
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=AxiQuad4Results(e2, nu2, alpha2, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)))
end