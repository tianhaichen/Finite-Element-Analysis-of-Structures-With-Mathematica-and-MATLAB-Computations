% Example 3.1
t = 1/2; ri = 3; ro = 9; rm = 6;
m = 0.283/386.4/1000; omega = 5000*2*pi/60; e = 30*10^3; nu = 0.3;
alpha = 0; deltaT = 0; br = 0; bz = 0;
nodes = [ri, 0; ri, t; rm, 0; rm, t; ro, 0; ro, t];
conn = [1, 3, 2; 3, 4, 2; 3, 5, 4; 5, 6, 4];
nel=size(conn,1); dof=2*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:3
        lm=[lm, [2*conn(i,j)-1,2*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = AxisymElasTriElement(e, nu, alpha, deltaT, ...
        omega, m, br, bz, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end

% Nodal solution and reactions
debc = [2, 6, 10]; ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals)
for i=1:nel
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=AxisymElasTriResults(e, nu, alpha, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)))

% % Test for AxisymTriLoad
% r = AxisymElasTriLoad(1, 1, 1, nodes(conn(1,:),:))
% r = AxisymElasTriLoad(2, 1, 1, nodes(conn(1,:),:))
% r = AxisymElasTriLoad(3, 1, 1, nodes(conn(1,:),:))
end