function [nsol, esol] = AntisymmetricTermsPipeColumn(nj, bj, ...
    e, nu, nodes, conn)
debc = [1,2,3,4,5,6]; ebcVals=zeros(length(debc),1);
nel=size(conn,1); dof=3*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:4
        lm=[lm, [3*conn(i,j)-2, 3*conn(i,j)-1, 3*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = AntisymmetricQuad4Element(nj, e, nu, nodes(con,:));
    r = r + AntisymmetricQuad4Load(2, bj, 0, 0, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, ebcVals);
theta = 0;
cn = cos(theta); sn = sin(theta);
nsol = [];
for i=1:3:dof
    nsol = [nsol,[d(i)*sn, -d(i+1)*cn, d(i+2)*sn]];
end
esol=[];
for i=1:nel
    EffectiveStress=AntisymmetricQuad4Results(nj, theta, e, nu, ...
        nodes(conn(i,:),:), d(lmm(i,:)));
    esol = [esol, EffectiveStress]; 
end
