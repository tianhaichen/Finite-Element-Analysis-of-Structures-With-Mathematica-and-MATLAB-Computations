function printResults(ns, es, nnodes, nelems)
fprintf(' Nodal displacements \n')
fprintf(' Node   Radial (u)   Circumferential (v)     Axial (z)\n')
fprintf(' ====   ==========   ===================     =========\n')
for i=1:nnodes
    fprintf(' %2d %11.4f %18.4f %18.4f \n', i, ns(3*i-2), ns(3*i-1), ns(3*i))
end
fprintf('\n\n vonMises stresses at element Gauss points\n')
fprintf(' Element             von Mises Stresses\n')
fprintf(' =======   ============================================\n')
for i=1:nelems
    fprintf(' %5d %11.4f %11.4f %11.4f %11.4f \n', i, es(4*i-3:4*i))
end
