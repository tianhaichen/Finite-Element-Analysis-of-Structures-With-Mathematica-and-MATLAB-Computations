function [u, v, w, sigp, sh] = ...
    MindlinShellElementSoln(gcoord, dg, h, e, nu)
% MindlinPlateElementSoln(coord, d, h, e, nu)
% Element solution for Mindlin plate element
% Input: d = Nodal solution
% coord = coordinates of element nodes,
% h = thickness, e = Young's modulus, nu = Poisson's ratio.
% Returns: {u, v, w, sigp, sh}
% where u, v, w = displacements,
% sigp = Maximum in-plane stresses {sx, sy, txy},
% sh = Shear stresses {tzx, tyz},
H = ShellDirectionCosines(gcoord);
coord=gcoord;
for i=1:size(gcoord,1)
    coord(i,:) = (H*gcoord(i,:)')';
end
T = zeros(24);
for i=1:3:24
    T(i:i+2,i:i+2)=H;
end
d = T*dg;
g = e/(2*(1 + nu)); dd = e*h^3/(12*(1 - nu^2));
dp = e /(1 - nu^2);
c = [1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
s=0; t=0;
n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
    (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
x = n*coord(:,1); y = n*coord(:,2);
dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
dys = dns*coord(:,2); dyt = dnt*coord(:,2);
J = [dxs, dxt; dys, dyt]; detJ = det(J);
bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
% Plane stress results
nlm = [1, 2, 7, 8, 13, 14, 19, 20];
disp = [n(1), 0, n(2), 0, n(3), 0, n(4), 0; ...
    0, n(1), 0, n(2), 0, n(3), 0, n(4)]*d(nlm);
u=disp(1); v = disp(2);
    b = [bx(1),0,bx(2),0,bx(3),0,bx(4),0;
        0,by(1),0,by(2),0,by(3),0,by(4);
        by(1),bx(1),by(2),bx(2),by(3),bx(3),by(4),bx(4)];
ep = b*d(nlm); sigp = dp*c*ep;
% Plate bending results
nt = [n(1),0,0,n(2),0,0,n(3),0,0,n(4),0,0];
nlm = [3, 4, 5, 9, 10, 11, 15, 16, 17, 21, 22, 23];
w=nt*d(nlm);
bt = [0,0,-bx(1),0,0,-bx(2),0,0,-bx(3),0,0,-bx(4);
    0,by(1),0,0,by(2),0,0,by(3),0,0,by(4),0;
    0,bx(1),-by(1),0,bx(2),-by(2),0,bx(3),-by(3),0,bx(4),-by(4)];
curv = bt*d(nlm);
m = -dd*c*curv;
sigp = sigp + 6/h^2 * m;
bt = [bx(1),0,n(1),bx(2),0,n(2),bx(3),0,n(3),bx(4),0,n(4);
    by(1),-n(1),0,by(2),-n(2),0,by(3),-n(3),0,by(4),-n(4),0];
sh=(1.5/h)*(5/6*g*h*bt*d(nlm));
end