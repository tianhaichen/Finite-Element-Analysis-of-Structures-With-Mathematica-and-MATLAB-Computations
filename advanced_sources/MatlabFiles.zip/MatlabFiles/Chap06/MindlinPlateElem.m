function [ke, re] = MindlinPlateElem(coord, h, e, nu, q)
% [ke, re] = MindlinPlateElem(coord, h, e, nu, q)
% Function to compute element stiffness and equivalent load vector.
% coord = element coordinates
% h = thickness
% e = Young's modulus, nu = Poisson's ratio
% q = distributed load.
% ke =  element stiffness, re =  equivalent load vector.
g = e/(2*(1 + nu)); d = e*h^3/(12*(1 - nu^2));
c = d*[1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
% Gauss point locations and weights
pt = 1/sqrt(3);
gBendLocs = [-pt, -pt; pt, -pt; -pt, pt; pt, pt];
gBendWts = [1, 1, 1, 1];
pt = 0;
gShearLocs = [[pt, pt]];
gShearWts = [4];
dof = 12;
ke=zeros(dof); re=zeros(dof,1);
for i=1:size(gBendLocs,1)
    s = gBendLocs(i, 1); t = gBendLocs(i, 2); w = gBendWts(i);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1); y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [0,0,-bx(1),0,0,-bx(2),0,0,-bx(3),0,0,-bx(4);
        0,by(1),0,0,by(2),0,0,by(3),0,0,by(4),0;
        0,bx(1),-by(1),0,bx(2),-by(2),0,bx(3),-by(3),0,bx(4),-by(4)];
    ke = ke + detJ*w* b'*c*b;
    re = re + detJ*w*q * [n(1),0,0,n(2),0,0,n(3),0,0,n(4),0,0]';
end
for i=1:size(gShearLocs,1)
    s = gShearLocs(i, 1); t = gShearLocs(i, 2); w = gShearWts(i);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1); y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [bx(1),0,n(1),bx(2),0,n(2),bx(3),0,n(3),bx(4),0,n(4);
        by(1),-n(1),0,by(2),-n(2),0,by(3),-n(3),0,by(4),-n(4),0];
    ke = ke + 5/6*g*h*detJ*w* b'*b;
end