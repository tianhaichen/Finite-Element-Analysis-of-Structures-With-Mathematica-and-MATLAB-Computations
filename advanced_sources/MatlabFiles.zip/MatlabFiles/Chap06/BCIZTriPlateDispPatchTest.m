% Prescribed displacement patch test
% BCIZ Triangular plate element
 h=0.1; e = 10^6; nu = 0.3; q = 0;
a = 20; b = 12; 
nodes = [0, 0; a, 0; a, b; 0, b; 3*a/5, 2*b/3];
conn = [1, 5, 4; 1, 2, 5; 2, 3, 5; 3, 4, 5];
ne = length(conn); nd = length(nodes); dof = 3*nd;
lmm = zeros(ne,9);
for i=1:ne
    lm1 = [3*conn(i,1) - 2, 3*conn(i,1) - 1, 3*conn(i,1)];
    lm2 = [3*conn(i,2) - 2, 3*conn(i,2) - 1, 3*conn(i,2)];
    lm3 = [3*conn(i,3) - 2, 3*conn(i,3) - 1, 3*conn(i,3)];
    lmm(i,:) = [lm1, lm2, lm3];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:ne
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = BCIZTriPlateElem(nodes(con,:), h, e, nu, q);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
debc = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
debcVals =[0., 0., 0., 0.04, 0.002, -0.004, 0.0784, 0.0044, ...
   -0.0052, 0.0144, 0.0024, -0.0012]; 
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, debcVals')
% Element solution
for i=1:ne
    fprintf(1,'Results for element %3.0g \n',i)
    [w, m, sigp] = BCIZTriPlateElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end