function [k, r] = MultiFieldMindlinPlateElem(coord, h, e, nu, q)
% [k, r] = MultiFieldMindlinPlateElem(coord, h, e, nu, q)
% Function to compute element stiffness and equivalent load vector.
% coord = element coordinates
% h = thickness
% e = Young's modulus, nu = Poisson's ratio
% q = distributed load.
% ke =  element stiffness, re =  equivalent load vector.
g = e/(2*(1 + nu)); dd = e*h^3/(12*(1 - nu^2));
c = dd*[1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
% Gauss point locations and weights
pt = 1/sqrt(3);
gLocs = [-pt, -pt; pt, -pt; -pt, pt; pt, pt];
gWts = [1, 1, 1, 1];
dof = 12;
ke=zeros(dof); r=zeros(dof,1);
nn = 4; nns = 1; nnb = 3;
k1 = zeros(nn, nns);
k2 = k1;
k3 = zeros(nn,nns);
k4 = zeros(nn,nnb);
k5 = k4;
k6 = zeros(nnb,nnb);
k7 = zeros(nns,nns);
for i=1:size(gLocs,1)
    s = gLocs(i, 1); t = gLocs(i, 2); w = gWts(i);
    n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
        (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
    nb = [1,s,t]; ns = [1];
    dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
    dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
    x = n*coord(:,1); y = n*coord(:,2);
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    k1 = k1 + detJ*w*bx'*ns;
    k2 = k2 + detJ*w*by'*ns;
    k3 = k3 + detJ*w*n'*ns;
    k4 = k4 + detJ*w*by'*nb;
    k5 = k5 + detJ*w*bx'*nb;
    k6 = k6 + detJ*w*nb'*nb;
    k7 = k7 + detJ*w*ns'*ns;
    r = r + detJ*w*q * [n(1),0,0,n(2),0,0,n(3),0,0,n(4),0,0]';
end
k7i = inv(k7); k6i = inv(k6);
k1T = k1'; k2T = k2';
k3T = k3'; k4T = k4'; k5T = k5';
k11 = 5/6*g*h*(k1*k7i*k1T + k2*k7i*k2T);
k12 = -5/6*g*h*k2*k7i*k3T;
k13 = 5/6*g*h*k1*k7i*k3T;
k21 = k12';
k22 = 5/6*g*h*k3*k7i*k3T + dd*(k4*k6i*k4T + (1 - nu)/2*k5*k6i*k5T);
k23 = -dd*(nu*k4*k6i*k5T + (1 - nu)/2*k5*k6i*k4T);
k31 = k13';
k32 = k23';
k33 = 5/6*g*h*k3*k7i*k3T + dd*(k5*k6i*k5T + (1 - nu)/2*k4*k6i*k4T);
ke(1:4,1:4) = k11;
ke(1:4,5:8) = k12;
ke(1:4,9:12) = k13;
ke(5:8,1:4) = k21;
ke(5:8,5:8) = k22;
ke(5:8,9:12) = k23;
ke(9:12,1:4) = k31;
ke(9:12,5:8) = k32;
ke(9:12,9:12) = k33;
nlm = [1, 5, 9, 2, 6, 10, 3, 7, 11, 4, 8, 12];
k = ke(nlm, nlm);
end