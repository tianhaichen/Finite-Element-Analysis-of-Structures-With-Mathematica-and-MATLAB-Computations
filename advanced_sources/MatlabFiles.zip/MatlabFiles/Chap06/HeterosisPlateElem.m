function [kc, re] = HeterosisPlateElem(coord, h, e, nu, q)
% [ke, re] = HeterosisPlateElem(coord, h, e, nu, q)
% Function to compute element stiffness and equivalent load vector.
% coord = element coordinates
% h = thickness
% e = Young's modulus, nu = Poisson's ratio
% q = distributed load.
% ke =  element stiffness, re =  equivalent load vector.
g = e/(2*(1 + nu)); d = e*h^3/(12*(1 - nu^2));
c = d*[1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
% Gauss point locations and weights
pt = sqrt(3/5);
gBendLocs = [-pt, -pt; -pt, 0; -pt, pt;
    0, -pt; 0, 0; 0, pt;
    pt, -pt; pt, 0; pt, pt];
gBendWts = [(5/9)*(5/9), (5/9)*(8/9), (5/9)*(5/9), ...
    (8/9)*(5/9), (8/9)*(8/9), (8/9)*(5/9), ...
    (5/9)*(5/9), (5/9)*(8/9), (5/9)*(5/9)];
pt = 1/sqrt(3);
gShearLocs = [-pt, -pt; pt, -pt; -pt, pt; pt, pt];
gShearWts = [1, 1, 1, 1];
dof = 26;
ke=zeros(dof); re=zeros(dof-2,1);
for i=1:size(gBendLocs,1)
    s = gBendLocs(i, 1);
    t = gBendLocs(i, 2);
    w = gBendWts(i);
    n = [((1-s)*(1-t))/4-((1-s^2)*(1-t))/4-((1-s)*(1-t^2))/4;
        ((1-s^2)*(1-t))/2;
        ((1+s)*(1-t))/4-((1-s^2)*(1-t))/4-((1+s)*(1-t^2))/4;
        ((1+s)*(1-t^2))/2;
        ((1+s)*(1+t))/4-((1-s^2)*(1+t))/4-((1+s)*(1-t^2))/4;
        ((1-s^2)*(1+t))/2;
        ((1-s)*(1+t))/4-((1-s^2)*(1+t))/4-((1-s)*(1-t^2))/4;
        ((1-s)*(1-t^2))/2
        ]';
    dns=[-((-1 + t)*(2*s + t))/4, s*(-1 + t),...
        -((2*s - t)*(-1 + t))/4, (1 - t^2)/2,...
        ((1 + t)*(2*s + t))/4, -(s*(1 + t)),...
        ((2*s - t)*(1 + t))/4, (-1 + t^2)/2];
    dnt=[-((-1 + s)*(s + 2*t))/4, (-1 + s^2)/2,...
        -((1 + s)*(s - 2*t))/4, -((1 + s)*t),...
        ((1 + s)*(s + 2*t))/4, (1 - s^2)/2,...
        ((-1 + s)*(s - 2*t))/4, (-1 + s)*t];
    dnls=[((-1 + 2*s)*(-1 + t)*t)/4, -(s*(-1 + t)*t),...
        ((1 + 2*s)*(-1 + t)*t)/4, -((1 + 2*s)*(-1 + t^2))/2,...
        ((1 + 2*s)*t*(1 + t))/4, -(s*t*(1 + t)),...
        ((-1 + 2*s)*t*(1 + t))/4, -((-1 + 2*s)*(-1 + t^2))/2,...
        2*s*(-1 + t^2)];
    dnlt=[((-1 + s)*s*(-1 + 2*t))/4, -((-1 + s^2)*(-1 + 2*t))/2,...
        (s*(1 + s)*(-1 + 2*t))/4, -(s*(1 + s)*t),...
        (s*(1 + s)*(1 + 2*t))/4, -((-1 + s^2)*(1 + 2*t))/2,...
        ((-1 + s)*s*(1 + 2*t))/4, -((-1 + s)*s*t), 2*(-1 + s^2)*t];
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    bx = (J(2, 2)*dnls - J(2, 1)*dnlt)/detJ;
    by = (-J(1, 2)*dnls + J(1, 1)*dnlt)/detJ;
    b = [0,0,-bx(1),0,0,-bx(2),0,0,-bx(3),0,0,-bx(4),...
        0,0,-bx(5),0,0,-bx(6),0,0,-bx(7),0,0,-bx(8),0,-bx(9);
        0,by(1),0,0,by(2),0,0,by(3),0,0,by(4),0,...
        0,by(5),0,0,by(6),0,0,by(7),0,0,by(8),0,by(9),0;
        0,bx(1),-by(1),0,bx(2),-by(2),0,bx(3),-by(3),0,bx(4),-by(4),...
        0,bx(5),-by(5),0,bx(6),-by(6),0,bx(7),-by(7),0,bx(8),-by(8),...
        bx(9),-by(9)];
    ke = ke + detJ*w* b'*c*b;
    re = re + detJ*w*q * [n(1),0,0,n(2),0,0,n(3),0,0,n(4),0,0,...
        n(5),0,0,n(6),0,0,n(7),0,0,n(8),0,0]';
end
for i=1:size(gShearLocs,1)
    s = gShearLocs(i, 1); t = gShearLocs(i, 2); w = gShearWts(i);
    n = [((1-s)*(1-t))/4-((1-s^2)*(1-t))/4-((1-s)*(1-t^2))/4;
        ((1-s^2)*(1-t))/2;
        ((1+s)*(1-t))/4-((1-s^2)*(1-t))/4-((1+s)*(1-t^2))/4;
        ((1+s)*(1-t^2))/2;
        ((1+s)*(1+t))/4-((1-s^2)*(1+t))/4-((1+s)*(1-t^2))/4;
        ((1-s^2)*(1+t))/2;
        ((1-s)*(1+t))/4-((1-s^2)*(1+t))/4-((1-s)*(1-t^2))/4;
        ((1-s)*(1-t^2))/2
        ]';
    dns=[-((-1 + t)*(2*s + t))/4, s*(-1 + t),...
        -((2*s - t)*(-1 + t))/4, (1 - t^2)/2,...
        ((1 + t)*(2*s + t))/4, -(s*(1 + t)),...
        ((2*s - t)*(1 + t))/4, (-1 + t^2)/2];
    dnt=[-((-1 + s)*(s + 2*t))/4, (-1 + s^2)/2,...
        -((1 + s)*(s - 2*t))/4, -((1 + s)*t),...
        ((1 + s)*(s + 2*t))/4, (1 - s^2)/2,...
        ((-1 + s)*(s - 2*t))/4, (-1 + s)*t];
    nl = [((-1+s)*s*(-1+t)*t)/4;
        -((-1+s)*(1+s)*(-1+t)*t)/2;
        (s*(1+s)*(-1+t)*t)/4;
        -(s*(1+s)*(-1+t)*(1+t))/2;
        (s*(1+s)*t*(1+t))/4;
        -((-1+s)*(1+s)*t*(1+t))/2;
        ((-1+s)*s*t*(1+t))/4;
        -((-1+s)*s*(-1+t)*(1+t))/2;
        (-1+s)*(1+s)*(-1+t)*(1+t)
        ]';
    dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    J = [dxs, dxt; dys, dyt]; detJ = det(J);
    bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
    by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
    b = [bx(1),0,nl(1),bx(2),0,nl(2),bx(3),0,nl(3),bx(4),0,nl(4),...
        bx(5),0,nl(5),bx(6),0,nl(6),bx(7),0,nl(7),bx(8),0,nl(8),0,nl(9);
        by(1),-nl(1),0,by(2),-nl(2),0,by(3),-nl(3),0,by(4),-nl(4),0,...
        by(5),-nl(5),0,by(6),-nl(6),0,by(7),-nl(7),0,by(8),-nl(8),0,...
        -nl(9),0];
    ke = ke + 5/6*g*h*detJ*w* b'*b;
    kc = StaticCondensation(ke,[1:1:24]);
end