% Numerical example
% Cylinderical shell
% 2x2 element solution
h=0.25; e = 4.32*10^8; nu = 0; q1 = 0; q2=0; q3=-36.7347*9.8*0.25;
nodes = [0, 0, 25; 25*sin(pi/9), 0, 25*cos(pi/9);
    25*sin((2*pi)/9), 0, 25*cos((2*pi)/9);
    0, 25/2, 25; 25*sin(pi/9), 25/2, 25*cos(pi/9);
    25*sin((2*pi)/9), 25/2, 25*cos((2*pi)/9);
    0, 25, 25; 25*sin(pi/9), 25, 25*cos(pi/9);
    25*sin((2*pi)/9), 25, 25*cos((2*pi)/9)];
conn = [1, 2, 5, 4; 2, 3, 6, 5; 4, 5, 8, 7; 5, 6, 9, 8];
ne = size(conn,1); nd = length(nodes); dof = 6*nd;
lmm = zeros(ne,24);
for i=1:ne
    lm1 = [6*conn(i,1)-5, 6*conn(i,1)-4, 6*conn(i,1)-3,...
        6*conn(i,1)-2, 6*conn(i,1)-1, 6*conn(i,1)];
    lm2 = [6*conn(i,2) - 5, 6*conn(i,2) - 4, 6*conn(i,2)-3,...
        6*conn(i,2)-2, 6*conn(i,2)-1, 6*conn(i,2)];
    lm3 = [6*conn(i,3) - 5, 6*conn(i,3) - 4, 6*conn(i,3)-3,...
        6*conn(i,3)-2, 6*conn(i,3)-1, 6*conn(i,3)];
    lm4 = [6*conn(i,4) - 5, 6*conn(i,4) - 4, 6*conn(i,4)-3,...
        6*conn(i,4)-2, 6*conn(i,4)-1, 6*conn(i,4)];
    lmm(i,:) = [lm1, lm2, lm3, lm4];
end
debc = [1, 3, 5, 6, 7, 9, 12, 13, 15, 18, 19, 23, 24, 37, 38, ...
 40, 41, 42, 44, 46, 48, 50, 52, 54];
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
rotzStiffFactor = 0.00001;
for i=1:ne
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = MindlinShellElem(nodes(con,:), h, e, nu, q1, q2, q3,...
        'Global', rotzStiffFactor);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, zeros(length(debc),1))
% Element solution
for i=1:ne
    fprintf(1,'Results for element %3.0g \n',i)
    [u, v, w, bendingStresses, shearStresses] = ...
        MindlinShellElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end