function [w, m, sigp, sh] = MindlinPlateElementSoln(coord, d, ...
    h, e, nu)
% MindlinPlateElementSoln(coord, d, h, e, nu)
% Element solution for Mindlin plate element
% Input: d = Nodal solution
% coord = coordinates of element nodes,
% h = thickness, e = Young's modulus, nu = Poisson's ratio.
% Returns: {w, m, sigp}
% where w = Transverse displacement,
% m = Bending moments {Mx, My, and Mxy},
% sigp = Maximum in-plane stresses {sx, sy, txy},
% sh = Shear stresses {tzx, tyz},
g = e/(2*(1 + nu));
dd = e*h^3/(12*(1 - nu^2));
c = dd*[1, nu, 0; nu, 1, 0; 0, 0, (1 - nu)/2];
s=0; t=0;
n = [(1/4)*(1 - s)*(1 - t), (1/4)*(s + 1)*(1 -t), ...
    (1/4)*(s + 1)*(t + 1), (1/4)*(1 - s)*(t + 1)];
dns=[(-1 + t)/4, (1 - t)/4, (1 + t)/4, (-1 - t)/4];
dnt=[(-1 + s)/4, (-1 - s)/4, (1 + s)/4, (1 - s)/4];
x = n*coord(:,1); y = n*coord(:,2);
dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
dys = dns*coord(:,2); dyt = dnt*coord(:,2);
J = [dxs, dxt; dys, dyt]; detJ = det(J);
bx = (J(2, 2)*dns - J(2, 1)*dnt)/detJ;
by = (-J(1, 2)*dns + J(1, 1)*dnt)/detJ;
nt = [n(1),0,0,n(2),0,0,n(3),0,0,n(4),0,0];
w=nt*d;
bt = [0,0,-bx(1),0,0,-bx(2),0,0,-bx(3),0,0,-bx(4);
    0,by(1),0,0,by(2),0,0,by(3),0,0,by(4),0;
    0,bx(1),-by(1),0,bx(2),-by(2),0,bx(3),-by(3),0,bx(4),-by(4)];
curv = bt*d;
m = -c*curv;
sigp = 6/h^2 * m;
bt = [bx(1),0,n(1),bx(2),0,n(2),bx(3),0,n(3),bx(4),0,n(4);
    by(1),-n(1),0,by(2),-n(2),0,by(3),-n(3),0,by(4),-n(4),0];
sh=5/6*g*h*bt*d;
end