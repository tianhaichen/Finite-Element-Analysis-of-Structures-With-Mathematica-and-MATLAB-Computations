% Constant twist patch test - Four corner loads
% MZC Rectangular plate element
 h=0.1; e = 10^6; nu = 0.3; q = 0;
nodes =[0, 0; 0, 5; 0, 8; 0, 10; 5, 0; 5, 5; 5, 8; 5, 10;
    15, 0; 15, 5; 15, 8; 15, 10; 30, 0; 30, 5; 30, 8; 30, 10];
conn = [1, 5, 6, 2; 2, 6, 7, 3; 3, 7, 8, 4; 5, 9, 10, 6;
    6, 10, 11, 7; 7, 11, 12, 8; 9, 13, 14, 10;
    10, 14, 15, 11; 11, 15, 16, 12];
lmm = [1, 2, 3, 13, 14, 15, 16, 17, 18, 4, 5, 6;
    4, 5, 6, 16, 17, 18, 19, 20, 21, 7, 8, 9;
    7, 8, 9, 19, 20, 21, 22, 23, 24, 10, 11, 12;
    13, 14, 15, 25, 26, 27, 28, 29, 30, 16, 17, 18;
    16, 17, 18, 28, 29, 30, 31, 32, 33, 19, 20, 21;
    19, 20, 21, 31, 32, 33, 34, 35, 36, 22, 23, 24;
    25, 26, 27, 37, 38, 39, 40, 41, 42, 28, 29, 30;
    28, 29, 30, 40, 41, 42, 43, 44, 45, 31, 32, 33;
    31, 32, 33, 43, 44, 45, 46, 47, 48, 34, 35, 36];
ne = length(conn); nd = length(coord); dof = 3*nd;
K=zeros(dof); R = zeros(dof,1);
% Form the load vector from line moment
m = 0.01; b = 5/2;
lm = lmm(7,:);
R(lm) = R(lm) + [0, 0, 0, 0, 0, -b*m, 0, 0, -b*m, 0, 0, 0]';
b = 3/2;
lm = lmm(8,:);
R(lm) = R(lm) +  [0, 0, 0, 0, 0, -b*m, 0, 0, -b*m, 0, 0, 0]';
b = 2/2;
lm = lmm(9,:);
R(lm) = R(lm) +  [0, 0, 0, 0, 0, -b*m, 0, 0, -b*m, 0, 0, 0]';
% Generate equations for each element and assemble them.
for i=1:ne
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = MZCRectPlateElem(nodes(con,:), h, e, nu, q);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
debc = [1, 2, 3, 6, 9, 12, 14, 26, 38];
debcVals =zeros(length(debc),1); 
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, debcVals)
% Element solution
for i=1:ne
    fprintf(1,'Results for element %3.0g \n',i)
    [w, m, sigp] = MZCRectPlateElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end