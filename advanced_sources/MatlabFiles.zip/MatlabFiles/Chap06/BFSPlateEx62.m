% Numerical example: (Example 6.2)
% BFS Rectangular plate element
h=0.1; e = 10920; nu = 0.3; q = 1;
nodes=[0,0; 0.5,0; 0.5,0.5; 0,0.5];
conn = [1,2,3,4];
lmm = [1:1:16];
K=zeros(16); R = zeros(16,1);
% Generate equations for each element and assemble them.
for i=1:1
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = BFSRectPlateElem(nodes(con,:), h, e, nu, q);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
K
R
debc = [1, 2, 3, 4, 5, 7, 8, 10, 11, 12, 13, 14, 15, 16];
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, zeros(length(debc),1))
% Element solution
for i=1:1
    fprintf(1,'Results for element %3.0g \n',i)
    [w, m, sigp] = BFSRectPlateElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end