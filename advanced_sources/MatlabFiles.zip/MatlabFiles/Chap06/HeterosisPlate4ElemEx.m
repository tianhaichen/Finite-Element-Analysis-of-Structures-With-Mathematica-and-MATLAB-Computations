% Numerical example
% Heterosis Plate Element
% Four element solution
h=0.1; e = 10920; nu = 0.3; q = 1;
nodes = [0,0; 0,1/8; 0,1/4; 0,3/8; 0,1/2; 1/8,0; 1/8,1/4;
    1/8,1/2; 1/4,0; 1/4,1/8; 1/4,1/4; 1/4,3/8;
    1/4,1/2; 3/8,0; 3/8,1/4; 3/8,1/2; 1/2,0;
    1/2,1/8; 1/2,1/4; 1/2,3/8; 1/2,1/2];
conn = [1,6,9,10,11,7,3,2; 3,7,11,12,13,8,5,4;
    9,14,17,18,19,15,11,10; 11,15,19,20,21,16,13,12];
ne = size(conn,1); nd = length(nodes); dof = 3*nd;
lmm = zeros(ne,24);
for i=1:ne
    lm1 = [3*conn(i,1) - 2, 3*conn(i,1) - 1, 3*conn(i,1)];
    lm2 = [3*conn(i,2) - 2, 3*conn(i,2) - 1, 3*conn(i,2)];
    lm3 = [3*conn(i,3) - 2, 3*conn(i,3) - 1, 3*conn(i,3)];
    lm4 = [3*conn(i,4) - 2, 3*conn(i,4) - 1, 3*conn(i,4)];
    lm5 = [3*conn(i,5) - 2, 3*conn(i,5) - 1, 3*conn(i,5)];
    lm6 = [3*conn(i,6) - 2, 3*conn(i,6) - 1, 3*conn(i,6)];
    lm7 = [3*conn(i,7) - 2, 3*conn(i,7) - 1, 3*conn(i,7)];
    lm8 = [3*conn(i,8) - 2, 3*conn(i,8) - 1, 3*conn(i,8)];
    lmm(i,:) = [lm1, lm2, lm3, lm4, lm5, lm6, lm7, lm8];
end
debc = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,...
    13, 14, 15, 16, 18, 25, 27, 40, 42,...
49, 51, 54, 57, 60, 62, 63, 47, 38, 23];
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:ne
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = HeterosisPlateElem(nodes(con,:), h, e, nu, q);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, zeros(length(debc),1))
% Element solution
for i=1:ne
    fprintf(1,'Results for element %3.0g \n',i)
    [w, m, bendingStresses, shearStresses] = HeterosisPlateElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end