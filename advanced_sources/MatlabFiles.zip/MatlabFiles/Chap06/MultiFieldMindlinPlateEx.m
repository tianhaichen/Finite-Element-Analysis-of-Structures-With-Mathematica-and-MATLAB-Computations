% Numerical example
% MultiField Mindlin Plate Element
% One element solution
h=0.1; e = 10920; nu = 0.3; q = 1;
a = 1/2; b = 1/2;
nodes = [0, 0; a, 0; a, b; 0, b];
conn = [[1, 2, 3,4]];
ne = size(conn,1); nd = length(nodes); dof = 3*nd;
lmm = zeros(ne,12);
for i=1:ne
    lm1 = [3*conn(i,1) - 2, 3*conn(i,1) - 1, 3*conn(i,1)];
    lm2 = [3*conn(i,2) - 2, 3*conn(i,2) - 1, 3*conn(i,2)];
    lm3 = [3*conn(i,3) - 2, 3*conn(i,3) - 1, 3*conn(i,3)];
    lm4 = [3*conn(i,4) - 2, 3*conn(i,4) - 1, 3*conn(i,4)];
    lmm(i,:) = [lm1, lm2, lm3, lm4];
end
debc = [1, 2, 3, 4, 6, 8, 9, 10, 11, 12];
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:ne
    con = conn(i,:);
    lm = lmm(i,:);
    [k,r] = MultiFieldMindlinPlateElem(nodes(con,:), h, e, nu, q);
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
K
R
% Nodal solution and reactions
[d, reactions] = NodalSoln(K, R, debc, zeros(length(debc),1))
% % Element solution
for i=1:ne
    fprintf(1,'Results for element %3.0g \n',i)
    [w, m, bendingStresses, shearStresses] = ...
        MultiFieldMindlinPlateElementSoln(nodes(conn(i,:),:),...
        d(lmm(i,:)), h, e, nu)
end