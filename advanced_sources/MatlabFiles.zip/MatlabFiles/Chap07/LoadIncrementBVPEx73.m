% Newton-Raphson with Load Increments: Example 7.3
lmm =[1, 2; 2, 3; 3, 4]; L = 1/3;
p=2/4; q=1;
re=q*L/2 *[1; 1];
dof = 4; ne = 3; d = [1; 2; 2; 2];
debc = [1];
df = setdiff(1:dof, debc);
for lambda = 2:2:4
    fprintf('Current load factor: %d \n', lambda);
    conv = 1; iter = 1; tol = 0.01;
    while(conv > tol & iter < 20)
        fprintf('Iteration: %d \n', iter);
        KT =zeros(dof); F = zeros(dof,1);
        R = zeros(dof,1); R(dof)=p;
        % Generate equations for each element and assemble them.
        for i=1:ne
            fprintf('Element: %d \n', i);
            lm = lmm(i,:);
            kde = kd(d(lm,:), L);
            kTe = kT(d(lm,:), L);
            KT(lm, lm) = KT(lm, lm) + kTe;
            F(lm) = F(lm) + kde;
            R(lm) = R(lm) + re;
        end
        dd = zeros(dof,1);
        Kf = KT(df, df)
        Rf = lambda*R(df); Ff = -F(df) + Rf
        conv = Ff'*Ff/(1+Rf'*Rf);
        fprintf('Convergence parameter: %f \n', conv);
        dd(df)=Kf\Ff; d = d + dd
        iter=iter+1;
    end
end

