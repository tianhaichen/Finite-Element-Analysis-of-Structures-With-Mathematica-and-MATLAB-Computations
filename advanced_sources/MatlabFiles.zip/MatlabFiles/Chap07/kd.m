function [kde] = kd(d, L)
% [kde] = kd(d, L)
% Element internal force vector
u1=d(1); u2=d(2);
kde = (1/(3*L))*[u1^3-u2^3; u2^3 - u1^3]
end
