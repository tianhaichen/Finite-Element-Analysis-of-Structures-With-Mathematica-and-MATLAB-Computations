% Arc-Length Method: Example 7.4
s = 1; lambda = 0.25; lambdaMax = 4; tol = 0.0005; iter = 1;
lmm =[1, 2; 2, 3; 3, 4]; L = 1/3;
p=2/lambdaMax; q=1;
re=q*L/2 *[1; 1];
dof = 4; ne = 3; d = [1; 1.5; 1.5; 1.5];
debc = [1];
df = setdiff(1:dof, debc);
while(lambda < lambdaMax)
    lambda = min(2*abs(lambda), lambdaMax);
    de = zeros(dof,1);
    if iter>1
        s = s*5/(iter-iterConverge);
        fprintf('Reset arc-length, s = %f\n', s)
    end
    iterConverge = iter;
    conv = 1;
    while(conv > tol & iter < 30)
        fprintf('*************************************\n');
        fprintf('Current load factor: %8.4f \n', lambda);
        fprintf('Iteration: %d \n', iter);
        fprintf('*************************************\n');
        KT =zeros(dof); F = zeros(dof,1);
        R = zeros(dof,1); R(dof)=p;
        % Generate equations for each element and assemble them.
        for i=1:ne
            fprintf('Element: %d \n', i);
            lm = lmm(i,:);
            kde = kd(d(lm,:), L);
            kTe = kT(d(lm,:), L);
            KT(lm, lm) = KT(lm, lm) + kTe;
            F(lm) = F(lm) + kde;
            R(lm) = R(lm) + re;
        end
        dd = zeros(dof,1);
        Kf = KT(df, df)
        lamRf = lambda*Rf;
        Rf = R(df);
        Ff = -F(df) + lamRf
        conv = (Ff'*Ff)/(1+(lamRf'*lamRf));
        fprintf('Convergence parameter: %f \n', conv);
        dlam = 0;
        if conv>tol
            a = Kf\Ff; b = Kf\Rf;
            a3 = b'*b;
            if iter==1
                dd(df) = a; s = lambda*sqrt(a3);
                fprintf('Initial arc-length, s = %f\n', s)
            else
                ade = a + de(df);
                a1 = ade'*ade - s^2;
                a2 = 2*ade'*b; a4 = a2^2 - 4*a3*a1;
                if a4>0
                    a4 = sqrt(a4);
                    dlam1 = (-a2+a4)/(2*a3);
                    dlam2 = (-a2-a4)/(2*a3);
                    d1 = de(df)'*(de(df)+a+b*dlam1);
                    d2 = de(df)'*(de(df)+a+b*dlam2);
                    if min(d1,d2)>=0
                        dlam3 = -a1/a2;
                        if abs(dlam1-dlam3)<abs(dlam2-dlam3)
                            dlam = dlam1;
                        else
                            dlam = dlam2;
                        end
                    elseif d1>0
                        dlam = dlam1;
                    elseif d2>0
                        dlam = dlam2;
                    end
                else
                    dlam = -min(max(con/tol,0.1),0.5)*lambda;
                end
                if lambda + dlam > lambdaMax
                    dlam = lambdaMax-lambda; lambda = lambdaMax;
                else
                    lambda = lambda + dlam;
                end
                dd(df) = a + b*dlam;
            end
        end
        fprintf ('Acceptable load factor increment = %8.4f \n',dlam);
        de = de + dd;
        d = d + dd
        iter=iter+1;
    end
end
