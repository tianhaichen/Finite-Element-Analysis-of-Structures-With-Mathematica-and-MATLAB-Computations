function [kTe] = kT(d, L)
% [kTe] = kT(d, L)
% Element tangent matrix
u1=d(1); u2=d(2);
kTe = (1/L)*[u1^2,-u2^2; -u1^2, u2^2]
end