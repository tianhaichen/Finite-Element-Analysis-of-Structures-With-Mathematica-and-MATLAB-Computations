function [kc] = StaticCondensation(k, m)
% [kc] = StaticCondensation(k, m)
% Perform static condensation on k using list m as master dof
s=setdiff(1:1:size(k,1), m);
kc = k(m,m) - k(m,s)* inv(k(s,s)) * k(s,m);
end
