function se = TetElementResults(e, nu, alpha, deltaT, coord, dn)
% se = TetElementResults(e, nu, alpha, deltaT, coord, dn)
% Computes element solution for a plane stress/strain triangular element
% e = modulus of elasticity
% nu = Poisson's ratio
% alpha = coefficient of thermal expansion
% deltaT = temperature change
% coord = nodal coordinates
% dn = nodal displacements
% Following are the output variables are at element center
% {strains, stresses, principal stresses, effective stress}
e0 = alpha*deltaT*[1; 1; 1; 0; 0; 0];
C = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0, 0, 0;
    nu, 1 - nu, nu, 0, 0, 0;
    nu, nu, 1 - nu, 0, 0, 0;
    0, 0, 0, (1 - 2*nu)/2, 0, 0;
    0, 0, 0, 0, (1 - 2*nu)/2, 0;
    0, 0, 0, 0, 0, (1 - 2*nu)/2];
[a1, a2, a3, a4, b1, b2, b3, b4, c1, c2, c3, c4, d1, d2, d3, d4, V] = ...
    TetInterpolationConstants(coord);
B = (1/(6*V))*[b1, 0, 0, c1, 0, d1;
    0, c1, 0, b1, d1, 0;
    0, 0, d1, 0, c1, b1;
    b2, 0, 0, c2, 0, d2;
    0, c2, 0, b2, d2, 0;
    0, 0, d2, 0, c2, b2;
    b3, 0, 0, c3, 0, d3;
    0, c3, 0, b3, d3, 0;
    0, 0, d3, 0, c3, b3;
    b4, 0, 0, c4, 0, d4;
    0, c4, 0, b4, d4, 0;
    0, 0, d4, 0, c4, b4];
eps = B'*dn;
sig = C*(eps-e0)
ps = eig([sig(1), sig(4), sig(6);
    sig(4), sig(2), sig(5);
    sig(6), sig(5), sig(3)]);
se = sqrt(((ps(1) - ps(2))^2 + (ps(2) - ps(3))^2 + (ps(3) - ps(1))^2)/2);
end
function [a1, a2, a3, a4, b1, b2, b3, b4, c1, c2, c3, ...
    c4, d1, d2, d3, d4, V] = TetInterpolationConstants(coord)
x1=coord(1,1); y1=coord(1,2); z1=coord(1,3);
x2=coord(2,1); y2=coord(2,2); z2=coord(2,3);
x3=coord(3,1); y3=coord(3,2); z3=coord(3,3);
x4=coord(4,1); y4=coord(4,2); z4=coord(4,3);
V = (x3*y2*z1 - x4*y2*z1 - x2*y3*z1 + x4*y3*z1 + ...
    x2*y4*z1 - x3*y4*z1 - x3*y1*z2 + x4*y1*z2 + ...
    x1*y3*z2 - x4*y3*z2 - x1*y4*z2 + x3*y4*z2 + ...
    x2*y1*z3 - x4*y1*z3 - x1*y2*z3 + x4*y2*z3 +...
    x1*y4*z3 - x2*y4*z3 - x2*y1*z4 + x3*y1*z4 +...
    x1*y2*z4 - x3*y2*z4 - x1*y3*z4 + x2*y3*z4)/6;
a1 = -(x4*y3*z2) + x3*y4*z2 + x4*y2*z3 - x2*y4*z3 - x3*y2*z4 +...
    x2*y3*z4;
a2 = x4*y3*z1 - x3*y4*z1 - x4*y1*z3 + ...
    x1*y4*z3 + x3*y1*z4 - x1*y3*z4;
a3 = -(x4*y2*z1) + x2*y4*z1 + x4*y1*z2 - ...
    x1*y4*z2 - x2*y1*z4 + x1*y2*z4;
a4 = x3*y2*z1 - x2*y3*z1 - x3*y1*z2 + x1*y3*z2 +...
    x2*y1*z3 - x1*y2*z3;
b1 = y4*(-z2 + z3) + y3*(z2 - z4) + y2*(-z3 + z4);
b2 = y4*(z1 - z3) + y1*(z3 - z4) + y3*(-z1 + z4);
b3 = y4*(-z1 + z2) + y2*(z1 - z4) + y1*(-z2 + z4);
b4 = y3*(z1 - z2) + y1*(z2 - z3) + y2*(-z1 + z3);
c1 = x4*(z2 - z3) + x2*(z3 - z4) + x3*(-z2 + z4);
c2 = x4*(-z1 + z3) + x3*(z1 - z4) + x1*(-z3 + z4);
c3 = x4*(z1 - z2) + x1*(z2 - z4) + x2*(-z1 + z4);
c4 = x3*(-z1 + z2) + x2*(z1 - z3) + x1*(-z2 + z3);
d1 = x4*(-y2 + y3) + x3*(y2 - y4) + x2*(-y3 + y4);
d2 = x4*(y1 - y3) + x1*(y3 - y4) + x3*(-y1 + y4);
d3 = x4*(-y1 + y2) + x2*(y1 - y4) + x1*(-y2 + y4);
d4 = x3*(y1 - y2) + x1*(y2 - y3) + x2*(-y1 + y3);
end