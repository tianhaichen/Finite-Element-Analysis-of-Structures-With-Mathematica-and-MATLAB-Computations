function [ke, re] = Solid8ElasElement(e, nu, alpha, deltaT, ...
    bx, by, bz, coord)
% [k, r] = Solid8ElasElement(e, nu, alpha, deltaT, bx, by, bz, coord)
% Generates equations for an 8 node solid element
% e = Modulus of elasticity
% nu = Poisson's ratio
% alpha = coefficient of thermal expansion
% deltaT = temperature change
% bx, by, bz = components of the body force
% coord = coordinates at the element ends
e0 = alpha*deltaT*[1; 1; 1; 0; 0; 0];
c = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0, 0, 0;
    nu, 1 - nu, nu, 0, 0, 0;
    nu, nu, 1 - nu, 0, 0, 0;
    0, 0, 0, (1 - 2*nu)/2, 0, 0;
    0, 0, 0, 0, (1 - 2*nu)/2, 0;
    0, 0, 0, 0, 0, (1 - 2*nu)/2];
% Use 2x2 integration. Gauss point locations and weights
pt=1/sqrt(3);
gpLocs = [-pt, -pt, -pt; -pt, -pt, pt; -pt, pt, -pt;...
    -pt, pt, pt; pt, -pt, -pt; pt, -pt, pt; pt, pt, -pt; pt, pt, pt];
gpWts = [1,1,1,1,1,1,1,1];
ke=zeros(24); re=zeros(24,1);
for i=1:length(gpWts)
    r = gpLocs(i, 1); s = gpLocs(i, 2); t = gpLocs(i, 3);
    w = gpWts(i);
    n = [(1/8)*(1 - r)*(1 - s)*(1 - t), (1/8)*(r + 1)*(1 - s)*(1 - t),...
        (1/8)*(r + 1)*(s + 1)*(1 - t), (1/8)*(1 - r)*(s + 1)*(1 - t),...
        (1/8)*(1 - r)*(1 - s)*(t + 1), (1/8)*(r + 1)*(1 - s)*(t + 1),...
        (1/8)*(r + 1)*(s + 1)*(t + 1), (1/8)*(1 - r)*(s + 1)*(t + 1)];
    dnr = [-((1 - s)*(1 - t))/8, ((1 - s)*(1 - t))/8, ...
        ((1 + s)*(1 - t))/8, -((1 + s)*(1 - t))/8,...
        -((1 - s)*(1 + t))/8, ((1 - s)*(1 + t))/8,...
        ((1 + s)*(1 + t))/8, -((1 + s)*(1 + t))/8];
    dns=[-((1 - r)*(1 - t))/8, -((1 + r)*(1 - t))/8, ...
        ((1 + r)*(1 - t))/8, ((1 - r)*(1 - t))/8, -((1 - r)*(1 + t))/8,...
        -((1 + r)*(1 + t))/8, ((1 + r)*(1 + t))/8, ((1 - r)*(1 + t))/8];
    dnt=[-((1 - r)*(1 - s))/8, -((1 + r)*(1 - s))/8, ...
        -((1 + r)*(1 + s))/8, -((1 - r)*(1 + s))/8, ...
        ((1 - r)*(1 - s))/8, ((1 + r)*(1 - s))/8, ...
        ((1 + r)*(1 + s))/8, ((1 - r)*(1 + s))/8];
    x = n*coord(:,1); y = n*coord(:,2); z = n*coord(:,3);
    dxr = dnr*coord(:,1); dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
    dyr = dnr*coord(:,2); dys = dns*coord(:,2); dyt = dnt*coord(:,2);
    dzr = dnr*coord(:,3); dzs = dns*coord(:,3); dzt = dnt*coord(:,3);
    JT = [dxr, dxs, dxt; dyr, dys, dyt; dzr, dzs, dzt]';
    detJ = det(JT);
    dnxyz = inv(JT)*[dnr; dns; dnt];
    dnx = dnxyz(1,:); dny = dnxyz(2,:); dnz = dnxyz(3,:);
    b=[];nn=[];
    for j=1:8
        b = [b; dnx(j), 0, 0, dny(j), 0, dnz(j);
            0, dny(j), 0, dnx(j), dnz(j), 0;
            0, 0, dnz(j), 0, dny(j), dnx(j)];
        nn = [nn; n(j),0,0; 0,n(j),0; 0,0,n(j)];
    end
    ke = ke + detJ*w* b*c*b';
    re = re + detJ*w*nn*[bx; by; bz]+ detJ*w*b*c*e0;
end