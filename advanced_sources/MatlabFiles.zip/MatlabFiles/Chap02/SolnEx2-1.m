% Solve the one tetrahedral element model shown in Figure 2.2
e=22*10^3; nu=0.15; alpha=11*10^(-6); deltaT=50;
nodes=[10,0,0; 40,0,0; 25,25,0; 25,0,25];
bx=0; by=0; bz =0; deltaT = 70;
conn = [[1, 2,3,4]];
nel=size(conn,1); dof=3*size(nodes,1);
lmm=[];
for i=1:nel
    lm = [];
    for j=1:4
        lm = [lm, [3*conn(i,j)-2, 3*conn(i,j)-1, 3*conn(i,j)]];
    end
    lmm = [lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = ElasticTetElement(e, nu, alpha, deltaT,...
        bx, by, bz, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
debc = [1:1:9]; ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals)
for i=1:nel
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=PlaneTriResults(e, nu, alpha, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)))
end