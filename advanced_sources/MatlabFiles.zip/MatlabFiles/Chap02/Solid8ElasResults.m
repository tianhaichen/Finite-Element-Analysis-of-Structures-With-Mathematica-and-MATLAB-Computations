function se = Solid8ElasResults(e, nu, alpha, deltaT, coord, dn)
% se = Solid8ElasResults(e, nu, alpha, deltaT, coord, dn)
% Computes element solution for a plane stress/strain quad element
% e = modulus of elasticity
% nu = Poisson's ratio
% alpha = coefficient of thermal expansion
% deltaT = temperature change
% coord = nodal coordinates
% dn = nodal displacements
% Following are the output variables are at element center
% {strains, stresses, principal stresses, effective stress}
e0 = alpha*deltaT*[1; 1; 1; 0; 0; 0];
c = e/((1 + nu)*(1 - 2*nu))*[1 - nu, nu, nu, 0, 0, 0;
    nu, 1 - nu, nu, 0, 0, 0;
    nu, nu, 1 - nu, 0, 0, 0;
    0, 0, 0, (1 - 2*nu)/2, 0, 0;
    0, 0, 0, 0, (1 - 2*nu)/2, 0;
    0, 0, 0, 0, 0, (1 - 2*nu)/2];
r=0; s = 0; t = 0;
n = [(1/8)*(1 - r)*(1 - s)*(1 - t), (1/8)*(r + 1)*(1 - s)*(1 - t),...
    (1/8)*(r + 1)*(s + 1)*(1 - t), (1/8)*(1 - r)*(s + 1)*(1 - t),...
    (1/8)*(1 - r)*(1 - s)*(t + 1), (1/8)*(r + 1)*(1 - s)*(t + 1),...
    (1/8)*(r + 1)*(s + 1)*(t + 1), (1/8)*(1 - r)*(s + 1)*(t + 1)];
dnr = [-((1 - s)*(1 - t))/8, ((1 - s)*(1 - t))/8, ...
    ((1 + s)*(1 - t))/8, -((1 + s)*(1 - t))/8,...
    -((1 - s)*(1 + t))/8, ((1 - s)*(1 + t))/8,...
    ((1 + s)*(1 + t))/8, -((1 + s)*(1 + t))/8];
dns=[-((1 - r)*(1 - t))/8, -((1 + r)*(1 - t))/8, ...
    ((1 + r)*(1 - t))/8, ((1 - r)*(1 - t))/8, -((1 - r)*(1 + t))/8,...
    -((1 + r)*(1 + t))/8, ((1 + r)*(1 + t))/8, ((1 - r)*(1 + t))/8];
dnt=[-((1 - r)*(1 - s))/8, -((1 + r)*(1 - s))/8, ...
    -((1 + r)*(1 + s))/8, -((1 - r)*(1 + s))/8, ...
    ((1 - r)*(1 - s))/8, ((1 + r)*(1 - s))/8, ...
    ((1 + r)*(1 + s))/8, ((1 - r)*(1 + s))/8];
x = n*coord(:,1); y = n*coord(:,2); z = n*coord(:,3);
dxr = dnr*coord(:,1); dxs = dns*coord(:,1); dxt = dnt*coord(:,1);
dyr = dnr*coord(:,2); dys = dns*coord(:,2); dyt = dnt*coord(:,2);
dzr = dnr*coord(:,3); dzs = dns*coord(:,3); dzt = dnt*coord(:,3);
JT = [dxr, dxs, dxt; dyr, dys, dyt; dzr, dzs, dzt]';
detJ = det(JT);
dnxyz = inv(JT)*[dnr; dns; dnt];
dnx = dnxyz(1,:); dny = dnxyz(2,:); dnz = dnxyz(3,:);
b=[];nn=[];
for j=1:8
    b = [b; dnx(j), 0, 0, dny(j), 0, dnz(j);
        0, dny(j), 0, dnx(j), dnz(j), 0;
        0, 0, dnz(j), 0, dny(j), dnx(j)];
end
eps = b'*dn;
sig = c*(eps-e0)
ps = eig([sig(1), sig(4), sig(6);
    sig(4), sig(2), sig(5);
    sig(6), sig(5), sig(3)]);
se = sqrt(((ps(1) - ps(2))^2 + (ps(2) - ps(3))^2 + (ps(3) - ps(1))^2)/2);
end