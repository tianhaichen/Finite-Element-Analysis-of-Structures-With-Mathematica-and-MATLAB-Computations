function rq = ElasticTetFaceNormalLoad(face, qn, coord)
% ElasticTetFaceNormalLoad(face, qn, coord)
% Generates equivalent load vector for a tetrahedral element
% face = face over which the load is specified
% qn = normal load
% coord = coordinates at the element ends

x1=coord(1,1); y1=coord(1,2); z1=coord(1,3);
x2=coord(2,1); y2=coord(2,2); z2=coord(2,3);
x3=coord(3,1); y3=coord(3,2); z3=coord(3,3);
x4=coord(4,1); y4=coord(4,2); z4=coord(4,3);
switch (face)
    case 1
       %Face 1 : 1 - 2 - 3
        v1 = [x2-x1, y2-y1, z2-z1]; v2 = [x3-x1, y3-y1, z3-z1];
        va = cross(v2, v1); nva = norm(va);
        n = va/nva; A = nva/2;
        [qx, qy, qz] = qn * n;
        rq = A/3 *[qx, qy, qz, qx, qy, qz, qx, qy, qz, 0, 0, 0]';
    case 2
       %Face 2 : 1 - 2 - 4
        v1 = [x4-x1, y4-y1, z4-z1]; v2 = [x2-x1, y2-y1, z2-z1];
        va = cross(v2, v1); nva = norm(va);
        n = va/nva; A = nva/2;
        [qx, qy, qz] = qn * n;
        rq = A/3 *[qx, qy, qz, qx, qy, qz, 0, 0, 0, qx, qy, qz]';
      case 3
       %Face 3 : 2 - 3 - 4
        v1 = [x4-x2, y4-y2, z4-z2]; v2 = [x3-x2, y3-y2, z3-z2];
        va = cross(v2, v1); nva = norm(va);
        n = va/nva; A = nva/2;
        [qx, qy, qz] = qn * n;
        rq = A/3 *[0, 0, 0, qx, qy, qz, qx, qy, qz, qx, qy, qz]';
      case 4
       %Face 4 : 3 - 4 - 1
        v1 = [x3-x1, y3-y1, z3-z1]; v2 = [x4-x1, y4-y1, z4-z1];
        va = cross(v2, v1); nva = norm(va);
        n = va/nva; A = nva/2;
        [qx, qy, qz] = qn * n;
        rq = A/3 *[qx, qy, qz, 0, 0, 0, qx, qy, qz, qx, qy, qz]';
end