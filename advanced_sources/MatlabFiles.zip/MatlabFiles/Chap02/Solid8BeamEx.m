% Cantilever beam using one 8 node solid element
e = 200*10^3; nu = 0.3; q = 10;
nodes = 100*[0, 0, 0; 4, 1, 0; 4, 2, 0; 0, 2, 0;...
    0, 0, 1; 4, 1, 1; 4, 2, 1; 0, 2, 1];
conn = [[1:8]];  
bx=0; by=0; bz=0; alpha=0; deltaT = 0;
nel=size(conn,1); dof=3*size(nodes,1);
lmm=[];
for i=1:nel
    lm=[];
    for j=1:8
        lm=[lm, [3*conn(i,j)-2, 3*conn(i,j)-1, 3*conn(i,j)]];
    end
    lmm=[lmm; lm];
end
K=zeros(dof); R = zeros(dof,1);
% Generate equations for each element and assemble them.
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    [k, r] = Solid8ElasElement(e, nu, alpha, deltaT, ...
        bx, by, bz, nodes(con,:));
    K(lm, lm) = K(lm, lm) + k;
    R(lm) = R(lm) + r;
end
% Add the distributed load contributions
for i=1:nel
    con = conn(i,:);
    lm = lmm(i,:);
    r = Solid8ElasFaceLoad(6, -q, nodes(con,:));
    R(lm) = R(lm) + r;
end
% Nodal solution and reactions
debc = [1, 2, 3, 10, 11, 12, 13, 14, 15, 22, 23, 24];
ebcVals=zeros(length(debc),1);
[d, reactions] = NodalSoln(K, R, debc, ebcVals)
for i=1:nel
    fprintf(1,'Results for element %3.0g \n',i)
    EffectiveStress=Solid8ElasResults(e, nu, alpha, deltaT, ...
        nodes(conn(i,:),:), d(lmm(i,:)))
end