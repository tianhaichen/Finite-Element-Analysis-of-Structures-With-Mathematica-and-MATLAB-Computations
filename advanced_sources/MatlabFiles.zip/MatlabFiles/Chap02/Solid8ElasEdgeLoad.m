function rq = Solid8ElasEdgeLoad(edge, q, coord)
% rq = Solid8ElasEdgeLoad(side, q, coord)
% Generates equivalent load vector for a triangular element
% edge = edge over which the load is specified
% q = load components
% coord = coordinates at the element ends

% Use 2 point integration. Gauss point locations and weights
pt=-1/sqrt(3);
gpLocs = [-pt, pt];
gpWts = [1,1];
rq=zeros(24,1);
for i=1:length(gpWts)
    a = gpLocs(i); w = gpWts(i);
    switch (edge)
    case 1
        n = [(1 - a)/2, (1 + a)/2, 0, 0, 0, 0, 0, 0];
        dna = [-1/2, 1/2, 0, 0, 0, 0, 0, 0];
    case 2
        n = [0, (1 - a)/2, (1 + a)/2, 0, 0, 0, 0, 0];
        dna = [0, -1/2, 1/2, 0, 0, 0, 0, 0];
    case 3
        n = [0, 0, (1 - a)/2, (1 + a)/2, 0, 0, 0, 0];
        dna = [0, 0, -1/2, 1/2, 0, 0, 0, 0];
    case 4
        n = [(1 + a)/2, 0, 0, (1 - a)/2, 0, 0, 0, 0];
        dna = [1/2, 0, 0, -1/2, 0, 0, 0, 0];
    case 5
        n = [(1 - a)/2, 0, 0, 0, (1 + a)/2, 0, 0, 0];
        dna = [-1/2, 0, 0, 0, 1/2, 0, 0, 0];
    case 6
        n = [0, (1 - a)/2, 0, 0, 0, (1 + a)/2, 0, 0];
        dna = [0, -1/2, 0, 0, 0, 1/2, 0, 0];
    case 7
        n = [0, 0, (1 - a)/2, 0, 0, 0, (1 + a)/2, 0];
        dna = [0, 0, -1/2, 0, 0, 0, 1/2, 0];
    case 8
        n = [0, 0, 0, (1 - a)/2, 0, 0, 0, (1 + a)/2];
        dna = [0, 0, 0, -1/2, 0, 0, 0, 1/2];
    case 9
        n = [0, 0, 0, 0, (1 - a)/2, (1 + a)/2, 0, 0];
        dna = [0, 0, 0, 0, -1/2, 1/2, 0, 0];
    case 10
        n = [0, 0, 0, 0, 0, (1 - a)/2, (1 + a)/2, 0];
        dna = [0, 0, 0, 0, 0, -1/2, 1/2, 0];
    case 11
        n = [0, 0, 0, 0, 0, 0, (1 - a)/2, (1 + a)/2];
        dna = [0, 0, 0, 0, 0, 0, -1/2, 1/2];
    case 12
        n = [0, 0, 0, 0, (1 + a)/2, 0, 0, (1 - a)/2];
        dna = [0, 0, 0, 0, 1/2, 0, 0, -1/2];
    end
    v = [dna*coord(:,1); dna*coord(:,2); dna*coord(:,3)];
    Jc=norm(v);
    nn=[];
    for j=1:8
        nn = [nn; n(j),0,0; 0,n(j),0; 0,0,n(j)];
    end
    rq = rq + Jc*w*nn*q;
end
