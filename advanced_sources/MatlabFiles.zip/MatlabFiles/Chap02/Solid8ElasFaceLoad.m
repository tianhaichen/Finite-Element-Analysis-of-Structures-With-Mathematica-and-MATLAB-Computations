function rq = Solid8ElasFaceLoad(face, qn, coord)
% rq = Solid8ElasFaceLoad(face, qn, coord)
% Generates equivalent load vector for a triangular element
% face = face over which the load is specified
% qn = load component in the normal direction
% coord = coordinates at the element ends

% Use 2x2 point integration. Gauss point locations and weights
pt=-1/sqrt(3);
gpLocs = [pt, pt; -pt, pt; pt, -pt; -pt, -pt];
gpWts = [1,1,1,1];
rq=zeros(24,1);
for i=1:length(gpWts)
    a = gpLocs(i,1); b = gpLocs(i,2); w = gpWts(i);
    switch (face)
        case 1
            n = [((1 - a)*(1 - b))/4, ((1 - a)*(1 + b))/4, ...
                ((1 + a)*(1 + b))/4,...
                ((1 + a)*(1 - b))/4, 0, 0, 0, 0];
            dna = [(-1 + b)/4, (-1 - b)/4, (1 + b)/4, (1 - b)/4,...
                0, 0, 0, 0];
            dnb = [(-1 + a)/4, (1 - a)/4, (1 + a)/4, (-1 - a)/4, ...
                0, 0, 0, 0];
        case 2
            n = [((1 - a)*(1 - b))/4, ((1 + a)*(1 - b))/4, 0,...
                0, ((1 - a)*(1 + b))/4, ((1 + a)*(1 + b))/4, 0, 0];
            dna = [(-1 + b)/4, (1 - b)/4, 0, 0, (-1 - b)/4, ...
                (1 + b)/4, 0, 0];
            dnb = [(-1 + a)/4, (-1 - a)/4, 0, 0, ...
                (1 - a)/4, (1 + a)/4, 0, 0];
        case 3
            n = [0, ((1 -a)*(1 - b))/4, ((1 + a)*(1 - b))/4,...
            0, 0, ((1 - a)*(1 + b))/4, ((1 + a)*(1 + b))/4, 0];
            dna = [0, (-1 + b)/4, (1 - b)/4, 0, 0, (-1 - b)/4,...
                (1 +b)/4, 0];
            dnb = [0, (-1 + a)/4, (-1 - a)/4, 0, 0, (1 - a)/4,...
                (1 + a)/4, 0];
        case 4
            n = [0, 0, ((1 - a)*(1 + b))/4, ((1 - a)*(1 - b))/4,...
                0, 0, ((1 + a)*(1 + b))/4, ((1 + a)*(1 - b))/4];
            dna = [0, 0, (-1 - b)/4, (-1 + b)/4, 0, 0, ...
                (1 + b)/4, (1 - b)/4];
            dnb = [0, 0, (1 - a)/4, (-1 + a)/4, 0, 0, ...
                (1 + a)/4, (-1 - a)/4];
        case 5
            n = [((1 - a)*(1 - b))/4, 0, 0, ((1 - a)*(1 + b))/4,...
                ((1 + a)*(1 - b))/4, 0, 0, ((1 + a)*(1 + b))/4];
            dna = [(-1 + b)/4,0, 0, (-1 - b)/4, (1 - b)/4, ...
                0, 0, (1 + b)/4];
            dnb = [(-1 + a)/4, 0, 0, (1 - a)/4, (-1 - a)/4,...
                0, 0, (1 + a)/4];
        case 6
            n = [0, 0, 0, 0, ((1 - a)*(1 - b))/4, ...
                ((1 + a)*(1 - b))/4, ((1 + a)*(1 +b))/4, ...
                ((1 - a)*(1 + b))/4];
            dna = [0, 0,0, 0, (-1 + b)/4, (1 -b)/4,...
                (1 + b)/4, (-1 - b)/4];
            dnb = [0, 0, 0, 0, (-1 + a)/4, (-1 -a)/4, ...
                (1 + a)/4, (1 - a)/4];
    end
    v1 = [dna*coord(:,1); dna*coord(:,2); dna*coord(:,3)];
    v2 = [dnb*coord(:,1); dnb*coord(:,2); dnb*coord(:,3)];
    va = cross(v1,v2); Js=norm(va); nv = va/Js;
    nn=[];
    for j=1:8
        nn = [nn; n(j),0,0; 0,n(j),0; 0,0,n(j)];
    end
    rq = rq + Js*w*qn*nn*nv;
end
