function [ri, snew, enew, newStatus, newep] = InelasticBarState(disps,...
    L, a, e, et, H, sY, type, sigma, eps, status, ep)
% function [ri, snew, enew, newStatus, newep] = InelasticBarState(disps,...
%    L, a, e, et, sY, type, sigma, eps, status, ep)
% Axial bar state determination
% disps = nodal displacements
% L = Bar length
% a = Area of cross section
% e = Elastic modulus
% et = Tangent modulus
% sY = Yield stress
% type = Strain hardening type (1: Kinematic, 2: Isotropic)
% sigma = Current stress
% eps = Current strain
% status = Current yield status (0: elastic, 1: yielded)
% ep = Current accumulated plastic strain
de = (1/L)* [-1, 1]* disps;
if type == 1
    [snew, enew, newStatus, newep] = KinematicHardening(e, et, H, sY,...
        de, sigma, eps, status, ep);
else
    [snew, enew, newStatus, newep] = IsotropicHardening(e, et, H, sY,...
        de, sigma, eps, status, ep);
end
p = a*snew;
ri = [-p; p];
end % InelasticBarState
