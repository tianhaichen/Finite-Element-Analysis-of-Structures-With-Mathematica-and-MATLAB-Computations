function [snew, enew, nstatus, newe0, news0] = RambergOsgood(e, sY, n, ...
    de, sigma, eps, status, e0, s0)
% [snew, enew, status, newe0, news0] = RambergOsgood(e, sY, n, ...
%    de, sigma, eps, status, e0, s0)
% Axial bar state determination with isotropic hardening
% e = Elastic modulus
% sY = Yield stress
% n = Ramberg-Osgood parameter
% de = Strain increment
% sigma = Current stress
% eps = Current strain
% status = Current status (0: loading, 1: unloading)
% e0, s0 = Strain and stress at previous unloading

nstatus=status;
newe0=0; news0=0;
switch (status)
    case {0}
        if de < 0
            nstatus = 1;
            newe0=eps; news0=sigma;
        end
    case {1}
        if de > 0
            nstatus = 0;
            newe0=eps; news0=sigma;
        end
    otherwise
        newe0=0; news0=0;
        if de < 0
            nstatus = 1;
        else
            nstatus = 0;
        end
end
enew = eps + de;
fcn = @(s)-(enew - newe0) + (s - news0)/e + (3/7)*((sY + ...
    abs(news0))/e)*((s - news0)/(sY + abs(news0)))^n;
snew = fzero(fcn,sigma);
end % RambergOsgood