function [ke, re] = InelasticTrussTangentEqns(e, et, status, coord, A)
% function [ke, re] = InelasticTrussTangentEqns(s, e, sY, n, s0, L, q, a)
% Axial bar tangent equations
% e = Elastic modulus
% et = Tangent modulus
% status = Current yield status (0: elastic, 1: yielded)
% A = area of cross-section
% coord = coordinates at the element ends

x1=coord(1,1); y1=coord(1,2);
x2=coord(2,1); y2=coord(2,2);
L=sqrt((x2-x1)^2+(y2-y1)^2);
ls=(x2-x1)/L; ms=(y2-y1)/L;
if status == 1
    cep = et;
else
    cep = e;
end
ke = cep*A/L*[ls^2, ls*ms,-ls^2,-ls*ms;
    ls*ms, ms^2,-ls*ms,-ms^2;
    -ls^2,-ls*ms,ls^2,ls*ms;
    -ls*ms,-ms^2,ls*ms,ms^2];
re = zeros(4,1);
end % InelasticTrussTangentEqns