function [snew, enew, status, newep] = IsotropicHardening(e, et, h, sY,...
    de, sigma, eps, yieldStatus, ep)
% function [snew, enew, status, newep] = IsotropicHardening(e, et, sY,...
%    de, sigma, eps, yieldStatus, ep)
% Axial bar state determination with isotropic hardening
% e = Elastic modulus
% et = Tangent modulus
% sY = Yield stress
% de = Strain increment
% sigma = Current stress
% eps = Current strain
% yieldStatus = Current yield status (0: elastic, 1: yielded)
% ep = Current accumulated plastic strain

status=yieldStatus; R = 1; ds = e*de;
s = sigma + ds; syc = sY + h*ep;
switch (yieldStatus)
    case {0}
        if abs(s) > syc
            status = 1;
            R = (syc - abs(sigma))/(abs(s) - abs(sigma));
        end
    case {1}
        if sigma*ds < 0
            status=0;
        else
            R=0;
        end
end
snew = sigma + R*ds + et*(1 - R)*de;
newep = ep + (1 - R)*de/(1 + (h/e));
enew = eps + de;
end % IsotropicHardening