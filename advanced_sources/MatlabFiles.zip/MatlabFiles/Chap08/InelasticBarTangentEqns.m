function [ke, re] = InelasticBarTangentEqns(e, et, status, L, q, a)
% function [ke, re] = InelasticBarTangentEqns(e, et, status, L, q, a)
% Axial bar tangent equations
% e = Elastic modulus
% et = Tangent modulus
% status = Current yield status (0: elastic, 1: yielded)
% L = Bar length
% q = axial distributed load
% a = Area of cross section

if status == 1
    cep = et;
else
    cep = e;
end
ke = cep*a/L * [1, -1; -1, 1];
re = q*L/2 * [1; 1];
end % InelasticBarTangentEqns