function [snew, enew, status, newep] = KinematicHardening(e, et, h, sY,...
    de, sigma, eps, yieldStatus, ep)
% function [snew, enew, status, newep] = KinematicHardening(e, et, sY,...
%    de, sigma, eps, yieldStatus, ep)
% Axial bar state determination with kinematic hardening
% e = Elastic modulus
% et = Tangent modulus
% sY = Yield stress
% de = Strain increment
% sigma = Current stress
% eps = Current strain
% yieldStatus = Current yield status (0: elastic, 1: yielded)
% ep = Current accumulated plastic strain

status=yieldStatus; R = 1; ds = e*de;
s = sigma + ds; a = h*ep;
switch (yieldStatus)
    case {0}
        if abs(s - a) > sY
            status = 1;
            R = (sY - abs(sigma - a))/(abs(s) - abs(sigma - a));
        end
    case {1}
        if sigma*ds < 0
            status=0;
        else
            R=0;
        end
end
snew = sigma + R*ds + et*(1 - R)*de;
newep = ep + (1 - R)*de/(1 + (h/e));
enew = eps + de;
end % KinematicHardening