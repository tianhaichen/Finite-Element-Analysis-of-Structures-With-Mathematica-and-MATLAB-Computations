function [ri, snew, enew, nstatus, news0, newe0]=RambergOsgoodBarState(...
    disps, L, a, e, sY, n, sigma, eps, status, s0, e0)
% [ri, snew, enew, ntatus, news0, newe0]=RambergOsgoodBarState(...
%    disps, L, a, e, sY, n, sigma, eps, status, s0, e0)
% Axial bar state determination with RambergOsgood model
% disps = nodal displacements
% L = Bar length
% a = Area of cross section
% e, sY, n = Ramberg Osgood parameters
% sigma = Current stress
% eps = Current strain
% status = Current status (0: loading, 1: unloading)
% s0, e0 = Stress and strain at previous unloading
de = (1/L)* [-1, 1]* disps;
[snew, enew, nstatus, newe0, news0] = RambergOsgood(e, sY, n, ...
    de, sigma, eps, status, e0, s0);
p = a*snew;
ri = [-p; p];
end % RambergOsgoodBarState
