% Example 8.3: Four bar truss
nodes = 1000*[0, -1; 4, 0; 4, 3; 2, 2];
dof=2*length(nodes);
conn=[1,2; 1,4; 2,4; 2,3];
lmm = [1, 2, 3, 4; 1, 2, 7, 8; 3, 4, 7, 8; 3, 4, 5, 6];
elems=size(lmm,1);
dof = 8; nel = 4; P = 40000; alpha = 60*pi/180;
debc = [1, 2, 5, 6]; ebcVals=zeros(length(debc),1);
df = [3, 4, 7, 8];
loadFactors = [1, 0];
A = 1000^2*[0.0004, 0.0004, 0.0002, 0.0002];
e = [200000, 200000, 200000, 200000];
sY = [150, 150, 150, 150];
type = [2, 2, 1, 1];
H = [10000, 10000, 10000, 10000];
for i=1:nel
    et(i) = e(i)*(1 - e(i)/(e(i) + H(i)));
end
sigma = [0,0,0,0]; eps = [0,0,0,0]; e0 = [0,0,0,0];
snew = [0,0,0,0]; enew = [0,0,0,0]; s0 = [0,0,0,0];
newep=[0,0,0,0];
status=[0,0,0,0]; nstatus = [0,0,0,0];
d = zeros(dof,1);
dd = zeros(dof,1); Ri=zeros(dof,1);
for step=1:length(loadFactors)
    lambda = loadFactors(step);
    fprintf(1,'**************************** \n')
    fprintf(1,'Current load parameter: %4.2g \n', lambda)
    fprintf(1,'**************************** \n')
    conv = 1; iter = 1; tol = 0.01; d = d + dd;
    dd = zeros(dof,1);
    for i=1:nel
        sigma(i)=snew(i);
        eps(i)=enew(i);
        status(i)=nstatus(i);
        ep(i)=newep(i);
    end
    while conv > tol & iter < 10
        fprintf(1,'Iteration: %3d \n', iter)
        KT = zeros(dof); R = zeros(dof,1); 
        R(3) = lambda*P*sin(alpha);
        R(4) = lambda*P*cos(alpha);
        R(7) = -lambda*P;
        for i=1:nel
            lm = lmm(i,:);
            con=conn(i,:);
            [k, r] = InelasticTrussTangentEqns(e(i), et(i), nstatus(i),...
                nodes(con,:), A(i));
            KT(lm, lm) = KT(lm, lm) + k;
            R(lm) = R(lm) + r;
        end
        KT
        R
        Ri
        % Nodal solution and reactions
        [ddd, reactions] = NodalSoln(KT, -Ri+R, debc, ebcVals);
        dd = dd + ddd;
        Ri=zeros(dof,1);
        fprintf(1,'Solution of incremental equations: \n')
        disp(ddd)
        fprintf(1,'Nodal solution increment in this load step: \n')
        disp(dd)
        fprintf(1,'Total nodal values: \n')
        disp(d+dd)
        for i=1:nel
            lm = lmm(i,:);
             con=conn(i,:);
           [ri, snew(i), enew(i), nstatus(i), newep(i)]= ...
                InelasticTrussState(dd(lm), nodes(con,:), A(i), e(i),...
                et(i), H(i), sY(i), type(i), sigma(i), ...
                eps(i), status(i), ep(i));
            Ri(lm) = Ri(lm) + ri;
        end
        fprintf(1,'Element status: \n')
        disp(nstatus)
        Rf = R(df); Ff = -Ri(df) + Rf;
        conv = (Ff'*Ff)/(1 + Rf'*Rf);
        fprintf(1,'Convergence parameter: %4.2g \n', conv)
        iter = iter + 1;
    end
end