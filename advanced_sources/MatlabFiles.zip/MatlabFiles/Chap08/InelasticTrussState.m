function [ri, snew, enew, nstatus, newep]=InelasticTrussState(...
    disps, coord, A, e, et, H, sY, type, sigma, eps, status, ep)
% [ri, snew, enew, nstatus, newep]=InelasticTrussState(...
%    disps, coord, A, e, et, h, sY, type, sigma, eps, status, ep)
% Truss element state determination
% disps = nodal displacements
% coord = coordinates at the element ends
% A = Area of cross section
% e = Elastic modulus
% et = Tangent modulus
% sY = Yield stress
% type = Strain hardening type (1: Kinematic, 2: Isotropic)
% sigma = Current stress
% eps = Current strain
% status = Current yield status (0: elastic, 1: yielded)
% ep = Current accumulated plastic strain

x1=coord(1,1); y1=coord(1,2);
x2=coord(2,1); y2=coord(2,2);
L=sqrt((x2-x1)^2+(y2-y1)^2);
ls=(x2-x1)/L; ms=(y2-y1)/L;
T = [ls, ms, 0, 0; 0, 0, ls, ms];
de = (1/L)* [-1, 1]* (T*disps);
if type == 1
    [snew, enew, nstatus, newep] = KinematicHardening(e, et, H, sY,...
        de, sigma, eps, status, ep);
else
    [snew, enew, nstatus, newep] = IsotropicHardening(e, et, H, sY,...
        de, sigma, eps, status, ep);
end
p = A*snew;
ri = T' * [-p; p];
end % InelasticTrussState
