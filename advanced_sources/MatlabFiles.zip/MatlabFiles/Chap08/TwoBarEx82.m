% Example 8.2: Two bars assembly
lmm = [1, 2; 2,3]; L = [15., 10.];
q = [0, 0];
dof = 3; nel = 2; P = 100;
debc = [1,3]; ebcVals=zeros(length(debc),1);
df = [2];
loadFactors = [1, 0];
A = [1, 2];
e = [10000, 29000]; n = [7, 11]; sY=[10, 60];
sigma = [0,0]; eps = [0,0]; e0 = [0,0];
snew = [0,0]; enew = [0,0]; s0 = [0,0];
news0=[0,0]; newe0=[0,0];
status=[0,0]; nstatus = [0,0];
d = zeros(dof,1);
dd = zeros(dof,1); Ri=zeros(dof,1);
for step=1:length(loadFactors)
    lambda = loadFactors(step);
    fprintf(1,'**************************** \n')
    fprintf(1,'Current load parameter: %4.2g \n', lambda)
    fprintf(1,'**************************** \n')
    conv = 1; iter = 1; tol = 0.01; d = d + dd;
    dd = zeros(dof,1);
    for i=1:nel
        sigma(i)=snew(i);
        eps(i)=enew(i);
        status(i)=nstatus(i);
        s0(i)=news0(i);
        e0(i)=newe0(i);
    end
    while conv > tol & iter < 10
        fprintf(1,'Iteration: %3d \n', iter)
        KT = zeros(dof); R = zeros(dof,1); R(2) = lambda*P;
        for i=1:nel
            lm = lmm(i,:);
            [k, r] = RambergOsgoodBarTangentEqns(snew(i), e(i), sY(i),...
                n(i), news0(i), L(i), lambda*q(i), A(i));
            KT(lm, lm) = KT(lm, lm) + k;
            R(lm) = R(lm) + r;
        end
        KT
        R
        Ri
        % Nodal solution and reactions
        [ddd, reactions] = NodalSoln(KT, -Ri+R, debc, ebcVals);
        dd = dd + ddd;
        Ri=zeros(dof,1);
        fprintf(1,'Solution of incremental equations: \n')
        disp(ddd')
        fprintf(1,'Nodal solution increment in this load step: \n')
        disp(dd')
        fprintf(1,'Total nodal values: \n')
        disp((d+dd)')
        for i=1:nel
            lm = lmm(i,:);
            [ri, snew(i), enew(i), nstatus(i), news0(i), newe0(i)]= ...
                RambergOsgoodBarState(dd(lm), L(i), A(i), e(i), sY(i), ...
                n(i), sigma(i), eps(i), status(i), s0(i), e0(i));
            Ri(lm) = Ri(lm) + ri;
        end
        fprintf(1,'Element status: \n')
        disp(nstatus)
        Rf = R(df); Ff = -Ri(df) + Rf;
        conv = (Ff'*Ff)/(1 + Rf'*Rf);
        fprintf(1,'Convergence parameter: %4.2g \n', conv)
        iter = iter + 1;
    end
end