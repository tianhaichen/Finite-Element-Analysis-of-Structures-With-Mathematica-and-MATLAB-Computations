function [ke, re] = RambergOsgoodBarTangentEqns(s, e, sY, n, s0, L, q, a)
% function [ke, re] = RambergOsgoodBarTangentEqns(s, e, sY, n, s0, L, q, a)
% Axial bar equations with RambergOsgood model
% e, sY, n = Ramberg Osgood parameters
% s0 = Stress at previous unloading
% s = current stress
% L = Bar length
% q = axial distributed load
% a = Area of cross section

cep = e/(1 + (3/7)*n *((s - s0)/(sY + abs(s0)))^(n - 1));
ke = cep*a/L * [1, -1; -1, 1];
re = q*L/2 * [1; 1];
end % RambergOsgoodBarTangentEqns