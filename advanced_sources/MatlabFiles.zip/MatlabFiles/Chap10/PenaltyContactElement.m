function k = PenaltyContactElement(coord, side, h, beta)
% k = PenaltyContactElement(pt, coord, side, beta)
% Form k matrix for contact element based on penalty formulation
% coord = coordinates of the target element
% side = target side of the element
% h = thickness
% beta = penalty parameter
% Use 2 point integration. Gauss point locations and weights
pt=-1/sqrt(3);
gpLocs = [-pt, pt];
gpWts = [1,1];
% Use 3 point integration. Gauss point locations and weights
pt=sqrt(3/5);
gpLocs = [-pt,0, pt];
gpWts = [5/9, 8/9, 5/9];
k = zeros(16);
for i=1:length(gpWts)
    a = gpLocs(i); w = gpWts(i);
    [xt, yt, dxa, dya, n] = sideMap8Node(a, coord, side);
    Jc=sqrt(dxa^2 + dya^2);
    cn = [dya; -dxa]/Jc;
    n = [n(1),0,n(2),0,n(3),0,n(4),0,n(5),0,n(6),0,n(7),0,n(8),0;
        0,n(1),0,n(2),0,n(3),0,n(4),0,n(5),0,n(6),0,n(7),0,n(8)]';
    Nn = n*cn;
    k = k + h*beta*Jc*w*Nn*Nn';
end
end % PenaltyContactElement