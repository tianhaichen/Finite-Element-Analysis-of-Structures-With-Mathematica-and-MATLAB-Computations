function dist = contactSignedDistance (pt, coord, side, prFlag)
% dist = contactSignedDistance (pt, cCoord, tCoord)
% Computes signed distance between the target side and a given point on a
% contactor side
% pt = given point on the contactor
% coord = coordinates of the target element
% side = target side of the element
xc = pt(1); yc=pt(2);
aa = fzero(@dfa,0);
[xt, yt, dxa, dya, nmap] = sideMap8Node(aa, coord, side);
Jc=sqrt(dxa^2 + dya^2);
cn = [dya; -dxa]/Jc;
dist = ([xc, yc] - [xt, yt])*cn;
if prFlag
    fprintf(1, 'Contactor point: (%-5.4g, %5.4g) \n', xc, yc);
    fprintf(1, 'Closest target point: (%-5.4g, %5.4g) \n', xt, yt);
    fprintf(1, 'Normal vector: (%-5.4g, %5.4g) \n', cn(1), cn(2));
end
fhandle = @dfa;
    function dd = dfa(a)
        [xt, yt, dxa, dya, nmap] = sideMap8Node(a, coord, side);
        dd = (xt - xc)*dxa + (yt - yc)*dya;
    end % dfa
end
