function [x, y, dxa, dya, nmap] = sideMap8Node(a, coord, side)
switch (side)
    case 1
        nmap = [((-1 + a)*a)/2, 1 - a^2, (a*(1 + a))/2, 0,...
            0, 0, 0, 0];
        dnamap = [-1/2 + a, -2*a, 1/2 + a, 0, 0, 0, 0, 0];
    case 2
        nmap = [0, 0, ((-1 + a)*a)/2, 1 - a^2, ...
            (a*(1 + a))/2, 0, 0, 0];
        dnamap = [0, 0, -1/2 + a, -2*a, 1/2 + a, 0, 0, 0];
    case 3
        nmap = [0, 0, 0, 0, ((-1 + a)*a)/2, 1 - a^2, ...
            (a*(1 + a))/2, 0];
        dnamap = [0, 0, 0, 0, -1/2 + a, -2*a, 1/2 + a, 0];
    case 4
        nmap = [a*(1 + a)/2, 0, 0, 0, 0, 0, ((-1 + a)*a)/2,...
            1 - a^2];
        dnamap = [1/2 + a, 0, 0, 0, 0, 0, -1/2 + a, -2*a];
end
x = nmap*coord(:,1); dxa = dnamap*coord(:,1);
y = nmap*coord(:,2); dya = dnamap*coord(:,2);
end % sideMap8Node
