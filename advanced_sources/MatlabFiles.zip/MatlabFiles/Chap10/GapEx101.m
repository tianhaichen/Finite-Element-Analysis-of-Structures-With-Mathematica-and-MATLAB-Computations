%Example 10.1: Gap calculation
% cCoord = [35/sqrt(2), 35/sqrt(2); 35*cos(pi/16), 35*sin(pi/16); 
%  35*cos(pi/8), -35*sin(pi/8); 50*cos(pi/8), -50*sin(pi/8);
%  50*cos(pi/16), 50*sin(pi/16); 25*sqrt(2), 25*sqrt(2));
% tCoord = [130 + 70*cos((7*pi)/8), 20 + 70*sin((7*pi)/8);
%     130 + 70*cos((17*pi)/16), 20 + 70*sin((17*pi)/16);
%     130 - 35*sqrt(2), 20 - 35*sqrt(2);
%     130 - 25*sqrt(2), 20 - 25*sqrt(2);
%     130 + 50*cos((17*pi)/16), 20 + 50*sin((17*pi)/16);
%     130 + 50*cos((7*pi)/8), 20 + 50*sin((7*pi)/8));
cCoord = [35/sqrt(2), 35/sqrt(2); 35*cos(pi/16), 35*sin(pi/16);
    35*cos(pi/8), -35*sin(pi/8); (85*cos(pi/8))/2, (-85*sin(pi/8))/2;
    50*cos(pi/8), -50*sin(pi/8); 50*cos(pi/16), 50*sin(pi/16);
    25*sqrt(2), 25*sqrt(2); 85/(2*sqrt(2)), 85/(2*sqrt(2))];
tCoord = [130 + 70*cos((7*pi)/8), 20 + 70*sin((7*pi)/8);
    130 + 70*cos((17*pi)/16), 20 + 70*sin((17*pi)/16);
    130 - 35*sqrt(2), 20 - 35*sqrt(2);
    130 - 30*sqrt(2), 20 - 30*sqrt(2);
    130 - 25*sqrt(2), 20 - 25*sqrt(2);
    130 + 50*cos((17*pi)/16), 20 + 50*sin((17*pi)/16);
    130 + 50*cos((7*pi)/8), 20 + 50*sin((7*pi)/8);
    130 + 60*cos((7*pi)/8), 20 + 60*sin((7*pi)/8)];
dist = contactSignedDistance (cCoord(6,:), tCoord, 1, true)